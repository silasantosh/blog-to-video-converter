/**
 * Blog to Video Converter v2.1
 * Fast rendering, theme-aware, preview before upload.
 */

const canvas = document.getElementById('btv-canvas');
if (!canvas) throw new Error('Canvas not found');
const ctx = canvas.getContext('2d');
const W = canvas.width;
const H = canvas.height;
const FPS = 30;

// UI Elements
const btn = document.getElementById('btv-generate-btn');
const progressContainer = document.getElementById('btv-progress-container');
const statusEl = document.getElementById('btv-status');
const sceneLabelEl = document.getElementById('btv-scene-label');
const progressBar = document.getElementById('btv-progress');
const percentEl = document.getElementById('btv-percent');
const etaEl = document.getElementById('btv-eta');
const previewSection = document.getElementById('btv-preview-section');
const previewPlayer = document.getElementById('btv-preview-player');
const uploadBtn = document.getElementById('btv-upload-btn');
const downloadBtn = document.getElementById('btv-download-btn');
const regenerateBtn = document.getElementById('btv-regenerate-btn');

// Current video blob (stored for preview/download/upload)
let currentBlob = null;

function log(msg) {
    console.log('[BTV]', msg);
    if (statusEl) statusEl.textContent = msg;
}

// ========== THEME SYSTEM ==========
const ts = (typeof btvData !== 'undefined' && btvData.theme_style) ? btvData.theme_style : {};

function cleanFont(raw) {
    if (!raw) return '';
    return raw.replace(/var\([^)]+\)/g, '').replace(/["']/g, '').trim();
}

const THEME = {
    primary: ts.primary || '#6c63ff',
    secondary: ts.secondary || '#ff6b6b',
    accent: ts.accent || '#ffcc00',
    background: ts.background || '#0f0c29',
    text: ts.text || '#ffffff',
    fontHeading: cleanFont(ts.fontHeading) || 'Arial, Helvetica, sans-serif',
    fontBody: cleanFont(ts.fontBody) || 'Arial, Helvetica, sans-serif',
};

function adjustColor(hex, amount) {
    hex = hex.replace('#', '');
    if (hex.length === 3) hex = hex.split('').map(c => c + c).join('');
    let r = parseInt(hex.substr(0, 2), 16) || 0;
    let g = parseInt(hex.substr(2, 2), 16) || 0;
    let b = parseInt(hex.substr(4, 2), 16) || 0;
    r = Math.min(255, Math.max(0, r + amount));
    g = Math.min(255, Math.max(0, g + amount));
    b = Math.min(255, Math.max(0, b + amount));
    return `rgb(${r},${g},${b})`;
}

function hexToRgba(hex, alpha) {
    hex = hex.replace('#', '');
    if (hex.length === 3) hex = hex.split('').map(c => c + c).join('');
    const r = parseInt(hex.substr(0, 2), 16) || 0;
    const g = parseInt(hex.substr(2, 2), 16) || 0;
    const b = parseInt(hex.substr(4, 2), 16) || 0;
    return `rgba(${r},${g},${b},${alpha})`;
}

const SCENE_LABELS = {
    brand_intro: '🏠 Website Intro',
    title_card: '📰 Post Title',
    content: '📝 Content',
    takeaway: '💡 Key Takeaway',
    outro: '👋 Outro & CTA',
};

// ========== STORYLINE BUILDER ==========
function buildStoryline() {
    const scenes = [];
    const site = btvData.site_name || 'Our Website';
    const siteUrl = btvData.site_url || '';
    const siteDesc = btvData.site_description || '';
    const title = btvData.post_title || 'Untitled Post';
    const excerpt = btvData.post_excerpt || '';
    const paragraphs = btvData.paragraphs || [];
    const images = [btvData.post_image, ...(btvData.content_images || [])].filter(Boolean);

    scenes.push({ type: 'brand_intro', duration: 5, siteName: site, siteDesc, siteUrl });
    scenes.push({ type: 'title_card', duration: 5, title, image: images[0] || null, siteName: site });

    if (paragraphs.length > 0) {
        paragraphs.forEach((text, i) => {
            scenes.push({
                type: 'content', duration: 6, text,
                sceneNumber: i + 1, totalScenes: paragraphs.length,
                image: images[(i + 1) % Math.max(images.length, 1)] || null,
                siteName: site,
            });
        });
    } else {
        scenes.push({
            type: 'content', duration: 10, text: excerpt,
            sceneNumber: 1, totalScenes: 1,
            image: images[0] || null, siteName: site,
        });
    }

    scenes.push({ type: 'takeaway', duration: 5, text: excerpt || paragraphs[0] || title, siteName: site });
    scenes.push({ type: 'outro', duration: 5, siteName: site, siteUrl, title });

    // Ensure minimum 30s
    let totalDur = scenes.reduce((sum, s) => sum + s.duration, 0);
    if (totalDur < 30) {
        const contentScenes = scenes.filter(s => s.type === 'content');
        const deficit = 30 - totalDur;
        const extra = Math.ceil(deficit / Math.max(contentScenes.length, 1));
        contentScenes.forEach(s => { s.duration += extra; });
    }

    return scenes;
}

// ========== SCENE RENDERERS ==========

function drawBrandIntro(progress, scene) {
    const grad = ctx.createLinearGradient(0, 0, W, H);
    grad.addColorStop(0, THEME.background);
    grad.addColorStop(0.5, adjustColor(THEME.background, 30));
    grad.addColorStop(1, adjustColor(THEME.background, -20));
    ctx.fillStyle = grad;
    ctx.fillRect(0, 0, W, H);

    for (let i = 0; i < 40; i++) {
        const x = (Math.sin(progress * 3 + i * 1.1) * 0.5 + 0.5) * W;
        const y = (Math.cos(progress * 2 + i * 0.7) * 0.5 + 0.5) * H;
        ctx.beginPath();
        ctx.arc(x, y, 2 + Math.sin(i) * 1.5, 0, Math.PI * 2);
        ctx.fillStyle = hexToRgba(THEME.primary, 0.1 + Math.sin(progress * 5 + i) * 0.1);
        ctx.fill();
    }

    const alpha = Math.min(1, progress * 3);
    ctx.globalAlpha = alpha;
    ctx.fillStyle = THEME.text;
    ctx.font = `bold 72px ${THEME.fontHeading}`;
    ctx.textAlign = 'center';
    ctx.textBaseline = 'middle';
    ctx.shadowColor = hexToRgba(THEME.primary, 0.5);
    ctx.shadowBlur = 25;
    ctx.fillText(scene.siteName, W / 2, H / 2 - 30);

    ctx.font = `28px ${THEME.fontBody}`;
    ctx.fillStyle = hexToRgba(THEME.primary, 0.7);
    ctx.shadowBlur = 0;
    ctx.fillText(scene.siteDesc, W / 2, H / 2 + 40);

    ctx.font = `20px ${THEME.fontBody}`;
    ctx.fillStyle = hexToRgba(THEME.text, 0.5);
    ctx.fillText(scene.siteUrl, W / 2, H / 2 + 80);

    const lineW = 200 * alpha;
    ctx.fillStyle = THEME.primary;
    ctx.fillRect(W / 2 - lineW / 2, H / 2 + 55, lineW, 3);
    ctx.globalAlpha = 1;
    ctx.shadowBlur = 0;
}

function drawTitleCard(progress, scene, img) {
    if (img) {
        ctx.filter = 'blur(15px) brightness(0.4)';
        ctx.drawImage(img, -20, -20, W + 40, H + 40);
        ctx.filter = 'none';
    } else {
        const grad = ctx.createLinearGradient(0, 0, W, H);
        grad.addColorStop(0, THEME.background);
        grad.addColorStop(1, adjustColor(THEME.background, 20));
        ctx.fillStyle = grad;
        ctx.fillRect(0, 0, W, H);
    }
    ctx.fillStyle = 'rgba(0,0,0,0.5)';
    ctx.fillRect(0, 0, W, H);

    const offsetY = Math.max(0, (1 - progress * 2) * 50);
    const alpha = Math.min(1, progress * 2.5);
    ctx.globalAlpha = alpha;

    ctx.fillStyle = THEME.text;
    ctx.font = `bold 64px ${THEME.fontHeading}`;
    ctx.textAlign = 'center';
    ctx.textBaseline = 'middle';
    ctx.shadowColor = 'rgba(0,0,0,0.8)';
    ctx.shadowBlur = 15;
    wrapText(scene.title, W / 2, H / 2 - 20 + offsetY, W - 200, 75);

    ctx.fillStyle = THEME.primary;
    ctx.shadowBlur = 0;
    const barW = 120 * alpha;
    ctx.fillRect(W / 2 - barW / 2, H / 2 + 60 + offsetY, barW, 4);

    ctx.font = `22px ${THEME.fontBody}`;
    ctx.fillStyle = hexToRgba(THEME.text, 0.6);
    ctx.textAlign = 'left';
    ctx.fillText(scene.siteName, 40, 40);
    ctx.globalAlpha = 1;
    ctx.shadowBlur = 0;
}

function drawContent(progress, scene, img) {
    if (img) {
        const scale = 1.0 + progress * 0.15;
        const dw = W * scale;
        const dh = (W / img.width * img.height) * scale;
        const dx = -(dw - W) / 2 + Math.sin(progress * 2) * 20;
        const dy = -(dh - H) / 2;
        ctx.drawImage(img, dx, dy, dw, dh);
        ctx.fillStyle = 'rgba(0,0,0,0.55)';
        ctx.fillRect(0, 0, W, H);
    } else {
        const grad = ctx.createLinearGradient(0, 0, W, H);
        grad.addColorStop(0, adjustColor(THEME.background, 10 + scene.sceneNumber * 8));
        grad.addColorStop(1, adjustColor(THEME.background, -10 + scene.sceneNumber * 5));
        ctx.fillStyle = grad;
        ctx.fillRect(0, 0, W, H);
    }

    ctx.fillStyle = hexToRgba(THEME.primary, 0.85);
    roundRect(40, 30, 120, 45, 22);
    ctx.fill();
    ctx.fillStyle = THEME.text;
    ctx.font = `bold 18px ${THEME.fontBody}`;
    ctx.textAlign = 'center';
    ctx.fillText(`${scene.sceneNumber} / ${scene.totalScenes}`, 100, 58);

    ctx.font = `18px ${THEME.fontBody}`;
    ctx.fillStyle = hexToRgba(THEME.text, 0.5);
    ctx.textAlign = 'right';
    ctx.fillText(scene.siteName, W - 40, 55);

    const boxH = 220, boxY = H - boxH - 30;
    ctx.fillStyle = 'rgba(0,0,0,0.7)';
    roundRect(40, boxY, W - 80, boxH, 16);
    ctx.fill();
    ctx.strokeStyle = hexToRgba(THEME.primary, 0.5);
    ctx.lineWidth = 2;
    roundRect(40, boxY, W - 80, boxH, 16);
    ctx.stroke();

    const charsToShow = Math.floor(progress * scene.text.length * 1.5);
    const visibleText = scene.text.substring(0, Math.min(charsToShow, scene.text.length));
    ctx.fillStyle = THEME.text;
    ctx.font = `28px ${THEME.fontBody}`;
    ctx.textAlign = 'left';
    ctx.textBaseline = 'top';
    wrapTextLeft(visibleText, 70, boxY + 25, W - 160, 38);
}

function drawTakeaway(progress, scene) {
    const grad = ctx.createLinearGradient(0, 0, W, H);
    grad.addColorStop(0, THEME.secondary);
    grad.addColorStop(1, adjustColor(THEME.secondary, -40));
    ctx.fillStyle = grad;
    ctx.fillRect(0, 0, W, H);

    ctx.fillStyle = hexToRgba(THEME.text, 0.12);
    ctx.font = 'bold 300px Georgia, serif';
    ctx.textAlign = 'center';
    ctx.fillText('\u201C', W / 2, H / 2 - 80);

    const alpha = Math.min(1, progress * 3);
    ctx.globalAlpha = alpha;
    ctx.fillStyle = THEME.text;
    ctx.font = `bold 36px ${THEME.fontHeading}`;
    ctx.textAlign = 'center';
    ctx.shadowColor = 'rgba(0,0,0,0.4)';
    ctx.shadowBlur = 10;
    wrapText(scene.text, W / 2, H / 2, W - 200, 48);

    ctx.font = `20px ${THEME.fontBody}`;
    ctx.fillStyle = hexToRgba(THEME.text, 0.7);
    ctx.shadowBlur = 0;
    ctx.fillText('\u2014 Key Takeaway \u2014', W / 2, H - 80);
    ctx.fillText(scene.siteName, W / 2, H - 50);
    ctx.globalAlpha = 1;
    ctx.shadowBlur = 0;
}

function drawOutro(progress, scene) {
    const grad = ctx.createLinearGradient(0, 0, W, H);
    grad.addColorStop(0, THEME.background);
    grad.addColorStop(0.5, adjustColor(THEME.background, 30));
    grad.addColorStop(1, THEME.background);
    ctx.fillStyle = grad;
    ctx.fillRect(0, 0, W, H);

    const alpha = Math.min(1, progress * 2);
    ctx.globalAlpha = alpha;
    ctx.fillStyle = THEME.text;
    ctx.font = `bold 52px ${THEME.fontHeading}`;
    ctx.textAlign = 'center';
    ctx.textBaseline = 'middle';
    ctx.fillText('Thanks for Watching!', W / 2, H / 2 - 80);

    ctx.fillStyle = THEME.primary;
    ctx.fillRect(W / 2 - 100, H / 2 - 30, 200, 3);

    ctx.font = `30px ${THEME.fontBody}`;
    ctx.fillStyle = hexToRgba(THEME.primary, 0.8);
    wrapText('\u201C' + scene.title + '\u201D', W / 2, H / 2 + 20, W - 200, 40);

    ctx.font = `bold 28px ${THEME.fontBody}`;
    ctx.fillStyle = THEME.accent;
    ctx.fillText('Read the full article at', W / 2, H / 2 + 90);

    ctx.font = `bold 32px ${THEME.fontHeading}`;
    ctx.fillStyle = THEME.text;
    ctx.fillText(scene.siteUrl, W / 2, H / 2 + 130);

    ctx.font = `20px ${THEME.fontBody}`;
    ctx.fillStyle = hexToRgba(THEME.text, 0.4);
    ctx.fillText('\u00A9 ' + scene.siteName, W / 2, H - 40);
    ctx.globalAlpha = 1;
}

// ========== HELPERS ==========

function wrapText(text, x, y, maxWidth, lineHeight) {
    const words = text.split(' ');
    let line = '';
    const lines = [];
    for (const word of words) {
        const test = line + word + ' ';
        if (ctx.measureText(test).width > maxWidth && line.length > 0) {
            lines.push(line.trim());
            line = word + ' ';
        } else { line = test; }
    }
    lines.push(line.trim());
    const startY = y - ((lines.length - 1) * lineHeight) / 2;
    for (let i = 0; i < lines.length; i++) ctx.fillText(lines[i], x, startY + i * lineHeight);
}

function wrapTextLeft(text, x, y, maxWidth, lineHeight) {
    const words = text.split(' ');
    let line = '', lineY = y;
    for (const word of words) {
        const test = line + word + ' ';
        if (ctx.measureText(test).width > maxWidth && line.length > 0) {
            ctx.fillText(line.trim(), x, lineY);
            line = word + ' ';
            lineY += lineHeight;
        } else { line = test; }
    }
    ctx.fillText(line.trim(), x, lineY);
}

function roundRect(x, y, w, h, r) {
    ctx.beginPath();
    ctx.moveTo(x + r, y);
    ctx.lineTo(x + w - r, y);
    ctx.quadraticCurveTo(x + w, y, x + w, y + r);
    ctx.lineTo(x + w, y + h - r);
    ctx.quadraticCurveTo(x + w, y + h, x + w - r, y + h);
    ctx.lineTo(x + r, y + h);
    ctx.quadraticCurveTo(x, y + h, x, y + h - r);
    ctx.lineTo(x, y + r);
    ctx.quadraticCurveTo(x, y, x + r, y);
    ctx.closePath();
}

function loadImage(url) {
    return new Promise(resolve => {
        const img = new Image();
        img.crossOrigin = 'anonymous';
        img.onload = () => resolve(img);
        img.onerror = () => resolve(null);
        img.src = url;
    });
}

// ========== FAST RENDER + PREVIEW ==========

async function generate() {
    log('Building storyline...');
    const scenes = buildStoryline();

    // Pre-load images
    log('Loading images...');
    const imageMap = new Map();
    for (const s of scenes) {
        if (s.image) {
            const img = await loadImage(s.image);
            if (img) imageMap.set(s.image, img);
        }
    }

    // Pollinations fallback for missing images
    for (const scene of scenes) {
        if (scene.type === 'content' && !imageMap.has(scene.image) && scene.image) {
            imageMap.delete(scene.image);
            scene.image = null;
        }
        if (scene.type === 'content' && !scene.image) {
            const kw = scene.text.split(' ').filter(w => w.length > 4).slice(0, 4).join(' ');
            if (kw) {
                const polUrl = `https://image.pollinations.ai/prompt/${encodeURIComponent(kw + ' professional photo')}?width=1280&height=720&nologo=true`;
                log(`Generating image for scene ${scene.sceneNumber}...`);
                const img = await loadImage(polUrl);
                if (img) { scene.image = polUrl; imageMap.set(polUrl, img); }
            }
        }
    }

    // Total frames
    let totalDuration = scenes.reduce((s, sc) => s + sc.duration, 0);
    const totalFrames = totalDuration * FPS;

    log('Recording video...');
    const stream = canvas.captureStream(FPS);
    const recorder = new MediaRecorder(stream, {
        mimeType: 'video/webm; codecs=vp8',
        videoBitsPerSecond: 4000000
    });
    const chunks = [];
    recorder.ondataavailable = e => { if (e.data.size > 0) chunks.push(e.data); };
    recorder.start(100);

    const startTime = performance.now();
    let frameIndex = 0;

    for (let si = 0; si < scenes.length; si++) {
        const scene = scenes[si];
        const sceneFrames = scene.duration * FPS;
        const img = scene.image ? imageMap.get(scene.image) : null;
        const label = SCENE_LABELS[scene.type] || scene.type;

        if (sceneLabelEl) sceneLabelEl.textContent = `Scene ${si + 1}/${scenes.length}: ${label}`;

        for (let f = 0; f < sceneFrames; f++) {
            const progress = f / sceneFrames;

            ctx.clearRect(0, 0, W, H);
            ctx.globalAlpha = 1;
            ctx.shadowBlur = 0;
            ctx.textAlign = 'center';
            ctx.textBaseline = 'middle';

            switch (scene.type) {
                case 'brand_intro': drawBrandIntro(progress, scene); break;
                case 'title_card': drawTitleCard(progress, scene, img); break;
                case 'content': drawContent(progress, scene, img); break;
                case 'takeaway': drawTakeaway(progress, scene); break;
                case 'outro': drawOutro(progress, scene); break;
            }

            frameIndex++;

            // Update UI every 10 frames (faster than every 30)
            if (frameIndex % 10 === 0) {
                const pct = Math.round((frameIndex / totalFrames) * 100);
                if (progressBar) progressBar.value = pct;
                if (percentEl) percentEl.textContent = `${pct}%`;

                // ETA calculation
                const elapsed = (performance.now() - startTime) / 1000;
                const rate = frameIndex / elapsed;
                const remaining = (totalFrames - frameIndex) / rate;
                if (etaEl) etaEl.textContent = remaining > 1 ? `~${Math.ceil(remaining)}s left` : 'Almost done...';

                log(`${pct}% — ${label}`);
            }

            // Yield to browser every 5 frames (fast but doesn't freeze)
            if (frameIndex % 5 === 0) {
                await new Promise(r => setTimeout(r, 0));
            }

            // Still need requestAnimationFrame for MediaRecorder to capture
            await new Promise(r => requestAnimationFrame(r));
        }
    }

    // Hold last frame
    await new Promise(r => setTimeout(r, 300));
    recorder.stop();
    log('Finalizing video...');
    await new Promise(r => (recorder.onstop = r));

    currentBlob = new Blob(chunks, { type: 'video/webm' });
    const sizeMB = (currentBlob.size / 1024 / 1024).toFixed(1);
    log(`✅ Video ready! (${sizeMB} MB)`);

    // Show preview
    const url = URL.createObjectURL(currentBlob);
    if (previewPlayer) previewPlayer.src = url;
    if (previewSection) previewSection.style.display = 'block';
    if (progressContainer) progressContainer.style.display = 'none';
    if (btn) btn.style.display = 'none';
}

async function uploadVideo() {
    if (!currentBlob) return;
    log('📤 Uploading to WordPress...');
    if (progressContainer) progressContainer.style.display = 'block';

    const formData = new FormData();
    formData.append('action', 'btv_upload_video');
    formData.append('nonce', btvData.nonce);
    formData.append('post_id', btvData.post_id);
    formData.append('video', currentBlob, 'blog-video-' + btvData.post_id + '.webm');

    try {
        const res = await fetch(btvData.ajaxurl, { method: 'POST', body: formData });
        const json = await res.json();
        if (json.success) {
            log('✅ Uploaded! Reloading...');
            setTimeout(() => location.reload(), 1500);
        } else {
            throw new Error(json.data || 'Upload failed');
        }
    } catch (e) {
        log('❌ Upload error: ' + e.message);
    }
}

function downloadVideo() {
    if (!currentBlob) return;
    const a = document.createElement('a');
    a.href = URL.createObjectURL(currentBlob);
    a.download = `blog-video-${btvData.post_id}.webm`;
    a.click();
}

function resetUI() {
    if (previewSection) previewSection.style.display = 'none';
    if (btn) { btn.style.display = 'block'; btn.disabled = false; }
    currentBlob = null;
}

// ========== EVENT LISTENERS ==========

if (btn) {
    btn.addEventListener('click', async () => {
        if (!confirm('Generate a video from this post?\n\nStoryline: Intro → Title → Content → Takeaway → Outro')) return;
        btn.disabled = true;
        if (progressContainer) progressContainer.style.display = 'block';
        log('Starting...');
        try { await generate(); }
        catch (e) { console.error(e); log('❌ ' + e.message); btn.disabled = false; }
    });
}

if (uploadBtn) uploadBtn.addEventListener('click', uploadVideo);
if (downloadBtn) downloadBtn.addEventListener('click', downloadVideo);
if (regenerateBtn) {
    regenerateBtn.addEventListener('click', () => {
        resetUI();
        btn.click();
    });
}
