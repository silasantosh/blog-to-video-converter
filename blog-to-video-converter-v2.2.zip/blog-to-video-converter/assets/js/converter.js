/**
 * Blog to Video Converter v2.2
 * Fixed: stuck rendering, added music, fade transitions, better visuals.
 */

const canvas = document.getElementById('btv-canvas');
if (!canvas) throw new Error('Canvas not found');
const ctx = canvas.getContext('2d');
const W = canvas.width;
const H = canvas.height;
const FPS = 24; // Lower FPS = faster render, still smooth

// UI Elements
const btn = document.getElementById('btv-generate-btn');
const progressContainer = document.getElementById('btv-progress-container');
const statusEl = document.getElementById('btv-status');
const sceneLabelEl = document.getElementById('btv-scene-label');
const progressBar = document.getElementById('btv-progress');
const percentEl = document.getElementById('btv-percent');
const etaEl = document.getElementById('btv-eta');
const previewSection = document.getElementById('btv-preview-section');
const previewPlayer = document.getElementById('btv-preview-player');
const uploadBtn = document.getElementById('btv-upload-btn');
const downloadBtn = document.getElementById('btv-download-btn');
const regenerateBtn = document.getElementById('btv-regenerate-btn');

let currentBlob = null;

function log(msg) {
    console.log('[BTV]', msg);
    if (statusEl) statusEl.textContent = msg;
}

// ========== THEME ==========
const ts = (typeof btvData !== 'undefined' && btvData.theme_style) ? btvData.theme_style : {};
function cleanFont(raw) {
    if (!raw) return '';
    return raw.replace(/var\([^)]+\)/g, '').replace(/["']/g, '').trim();
}

const THEME = {
    primary: ts.primary || '#6c63ff',
    secondary: ts.secondary || '#ff6b6b',
    accent: ts.accent || '#ffcc00',
    background: ts.background || '#0f0c29',
    text: ts.text || '#ffffff',
    fontHeading: cleanFont(ts.fontHeading) || 'Arial, Helvetica, sans-serif',
    fontBody: cleanFont(ts.fontBody) || 'Arial, Helvetica, sans-serif',
};

function adjustColor(hex, amt) {
    hex = hex.replace('#', '');
    if (hex.length === 3) hex = hex.split('').map(c => c + c).join('');
    let r = parseInt(hex.substr(0, 2), 16) || 0;
    let g = parseInt(hex.substr(2, 2), 16) || 0;
    let b = parseInt(hex.substr(4, 2), 16) || 0;
    r = Math.min(255, Math.max(0, r + amt));
    g = Math.min(255, Math.max(0, g + amt));
    b = Math.min(255, Math.max(0, b + amt));
    return `rgb(${r},${g},${b})`;
}

function hexToRgba(hex, a) {
    hex = hex.replace('#', '');
    if (hex.length === 3) hex = hex.split('').map(c => c + c).join('');
    const r = parseInt(hex.substr(0, 2), 16) || 0;
    const g = parseInt(hex.substr(2, 2), 16) || 0;
    const b = parseInt(hex.substr(4, 2), 16) || 0;
    return `rgba(${r},${g},${b},${a})`;
}

const SCENE_LABELS = {
    brand_intro: '\u{1F3E0} Website Intro',
    title_card: '\u{1F4F0} Post Title',
    content: '\u{1F4DD} Content',
    takeaway: '\u{1F4A1} Key Takeaway',
    outro: '\u{1F44B} Outro & CTA',
};

// ========== BACKGROUND MUSIC (Web Audio API) ==========
let audioCtx = null;
let musicDest = null;

function createBackgroundMusic(durationSec) {
    audioCtx = new (window.AudioContext || window.webkitAudioContext)();
    musicDest = audioCtx.createMediaStreamDestination();

    // Master gain
    const master = audioCtx.createGain();
    master.gain.setValueAtTime(0.15, audioCtx.currentTime);
    master.connect(musicDest);
    master.connect(audioCtx.destination); // also play through speakers (optional)

    // Ambient pad — soft sine waves
    const notes = [261.63, 329.63, 392.00, 440.00, 523.25]; // C4, E4, G4, A4, C5
    const now = audioCtx.currentTime;

    for (let i = 0; i < notes.length; i++) {
        const osc = audioCtx.createOscillator();
        const gain = audioCtx.createGain();
        osc.type = 'sine';
        osc.frequency.setValueAtTime(notes[i], now);

        // Slow LFO modulation for movement
        const lfo = audioCtx.createOscillator();
        const lfoGain = audioCtx.createGain();
        lfo.type = 'sine';
        lfo.frequency.setValueAtTime(0.1 + i * 0.05, now);
        lfoGain.gain.setValueAtTime(3, now);
        lfo.connect(lfoGain);
        lfoGain.connect(osc.frequency);
        lfo.start(now);
        lfo.stop(now + durationSec + 1);

        // Volume envelope — fade in/out per note
        gain.gain.setValueAtTime(0, now);
        gain.gain.linearRampToValueAtTime(0.04, now + 2 + i * 0.5);
        gain.gain.setValueAtTime(0.04, now + durationSec - 3);
        gain.gain.linearRampToValueAtTime(0, now + durationSec);

        osc.connect(gain);
        gain.connect(master);
        osc.start(now + i * 0.3);
        osc.stop(now + durationSec + 1);
    }

    // Soft rhythm — very subtle kick
    for (let t = 0; t < durationSec; t += 2) {
        const kick = audioCtx.createOscillator();
        const kickGain = audioCtx.createGain();
        kick.type = 'sine';
        kick.frequency.setValueAtTime(80, now + t);
        kick.frequency.exponentialRampToValueAtTime(30, now + t + 0.15);
        kickGain.gain.setValueAtTime(0.06, now + t);
        kickGain.gain.exponentialRampToValueAtTime(0.001, now + t + 0.3);
        kick.connect(kickGain);
        kickGain.connect(master);
        kick.start(now + t);
        kick.stop(now + t + 0.4);
    }

    // Gentle chime melody
    const melody = [523.25, 659.25, 783.99, 659.25, 523.25, 783.99, 880, 659.25];
    for (let i = 0; i < Math.floor(durationSec / 4); i++) {
        const note = melody[i % melody.length];
        const chime = audioCtx.createOscillator();
        const chimeGain = audioCtx.createGain();
        const chimeFilter = audioCtx.createBiquadFilter();
        chime.type = 'triangle';
        chime.frequency.setValueAtTime(note, now + i * 4 + 1);
        chimeFilter.type = 'lowpass';
        chimeFilter.frequency.setValueAtTime(2000, now);
        chimeGain.gain.setValueAtTime(0, now + i * 4 + 1);
        chimeGain.gain.linearRampToValueAtTime(0.03, now + i * 4 + 1.1);
        chimeGain.gain.exponentialRampToValueAtTime(0.001, now + i * 4 + 3);
        chime.connect(chimeFilter);
        chimeFilter.connect(chimeGain);
        chimeGain.connect(master);
        chime.start(now + i * 4 + 1);
        chime.stop(now + i * 4 + 4);
    }

    return musicDest.stream;
}

// ========== STORYLINE ==========
function buildStoryline() {
    const scenes = [];
    const site = btvData.site_name || 'Our Website';
    const siteUrl = btvData.site_url || '';
    const siteDesc = btvData.site_description || '';
    const title = btvData.post_title || 'Untitled Post';
    const excerpt = btvData.post_excerpt || '';
    const paragraphs = btvData.paragraphs || [];
    const images = [btvData.post_image, ...(btvData.content_images || [])].filter(Boolean);

    scenes.push({ type: 'brand_intro', duration: 5, siteName: site, siteDesc, siteUrl });
    scenes.push({ type: 'title_card', duration: 5, title, image: images[0] || null, siteName: site });

    if (paragraphs.length > 0) {
        paragraphs.forEach((text, i) => {
            scenes.push({
                type: 'content', duration: 6, text,
                sceneNumber: i + 1, totalScenes: paragraphs.length,
                image: images[(i + 1) % Math.max(images.length, 1)] || null,
                siteName: site,
            });
        });
    } else {
        scenes.push({
            type: 'content', duration: 12, text: excerpt,
            sceneNumber: 1, totalScenes: 1,
            image: images[0] || null, siteName: site,
        });
    }

    scenes.push({ type: 'takeaway', duration: 5, text: excerpt || paragraphs[0] || title, siteName: site });
    scenes.push({ type: 'outro', duration: 5, siteName: site, siteUrl, title });

    // Min 30s
    let totalDur = scenes.reduce((s, sc) => s + sc.duration, 0);
    if (totalDur < 30) {
        const cs = scenes.filter(s => s.type === 'content');
        const extra = Math.ceil((30 - totalDur) / Math.max(cs.length, 1));
        cs.forEach(s => { s.duration += extra; });
    }
    return scenes;
}

// ========== DRAWING HELPERS ==========

function wrapText(text, x, y, maxW, lh) {
    const words = text.split(' ');
    let line = '';
    const lines = [];
    for (const w of words) {
        const t = line + w + ' ';
        if (ctx.measureText(t).width > maxW && line) { lines.push(line.trim()); line = w + ' '; }
        else line = t;
    }
    lines.push(line.trim());
    const sy = y - ((lines.length - 1) * lh) / 2;
    for (let i = 0; i < lines.length; i++) ctx.fillText(lines[i], x, sy + i * lh);
}

function wrapTextLeft(text, x, y, maxW, lh) {
    const words = text.split(' ');
    let line = '', ly = y;
    for (const w of words) {
        const t = line + w + ' ';
        if (ctx.measureText(t).width > maxW && line) { ctx.fillText(line.trim(), x, ly); line = w + ' '; ly += lh; }
        else line = t;
    }
    ctx.fillText(line.trim(), x, ly);
}

function roundRect(x, y, w, h, r) {
    ctx.beginPath();
    ctx.moveTo(x + r, y); ctx.lineTo(x + w - r, y);
    ctx.quadraticCurveTo(x + w, y, x + w, y + r); ctx.lineTo(x + w, y + h - r);
    ctx.quadraticCurveTo(x + w, y + h, x + w - r, y + h); ctx.lineTo(x + r, y + h);
    ctx.quadraticCurveTo(x, y + h, x, y + h - r); ctx.lineTo(x, y + r);
    ctx.quadraticCurveTo(x, y, x + r, y); ctx.closePath();
}

function loadImage(url) {
    return new Promise(resolve => {
        if (!url) return resolve(null);
        const img = new Image();
        img.crossOrigin = 'anonymous';
        img.onload = () => resolve(img);
        img.onerror = () => resolve(null);
        img.src = url;
    });
}

// Smooth ease-in-out
function ease(t) { return t < 0.5 ? 2 * t * t : 1 - Math.pow(-2 * t + 2, 2) / 2; }

// ========== SCENE RENDERERS ==========

function drawBrandIntro(p, scene) {
    const grad = ctx.createRadialGradient(W / 2, H / 2, 0, W / 2, H / 2, W * 0.8);
    grad.addColorStop(0, adjustColor(THEME.background, 40));
    grad.addColorStop(1, THEME.background);
    ctx.fillStyle = grad;
    ctx.fillRect(0, 0, W, H);

    // Floating orbs
    for (let i = 0; i < 50; i++) {
        const angle = p * 2 + i * 0.7;
        const radius = 150 + Math.sin(i * 0.5) * 250;
        const x = W / 2 + Math.cos(angle) * radius;
        const y = H / 2 + Math.sin(angle * 0.6) * (radius * 0.5);
        const size = 2 + Math.sin(p * 4 + i) * 2;
        ctx.beginPath();
        ctx.arc(x, y, size, 0, Math.PI * 2);
        ctx.fillStyle = hexToRgba(THEME.primary, 0.08 + Math.sin(p * 3 + i) * 0.06);
        ctx.fill();
    }

    // Glowing ring
    ctx.beginPath();
    ctx.arc(W / 2, H / 2, 180 + Math.sin(p * 3) * 20, 0, Math.PI * 2);
    ctx.strokeStyle = hexToRgba(THEME.primary, 0.15 * ease(p));
    ctx.lineWidth = 2;
    ctx.stroke();

    const alpha = ease(Math.min(1, p * 2.5));
    ctx.globalAlpha = alpha;

    // Site name
    ctx.fillStyle = THEME.text;
    ctx.font = `bold 76px ${THEME.fontHeading}`;
    ctx.textAlign = 'center';
    ctx.textBaseline = 'middle';
    ctx.shadowColor = hexToRgba(THEME.primary, 0.6);
    ctx.shadowBlur = 30;
    ctx.fillText(scene.siteName, W / 2, H / 2 - 35);
    ctx.shadowBlur = 0;

    // Accent line
    const lw = 240 * alpha;
    ctx.fillStyle = THEME.primary;
    ctx.fillRect(W / 2 - lw / 2, H / 2 + 10, lw, 3);

    // Tagline
    ctx.font = `26px ${THEME.fontBody}`;
    ctx.fillStyle = hexToRgba(THEME.text, 0.65);
    ctx.fillText(scene.siteDesc, W / 2, H / 2 + 45);

    // URL
    ctx.font = `18px ${THEME.fontBody}`;
    ctx.fillStyle = hexToRgba(THEME.text, 0.4);
    ctx.fillText(scene.siteUrl, W / 2, H / 2 + 80);

    ctx.globalAlpha = 1;
}

function drawTitleCard(p, scene, img) {
    if (img) {
        // Animated zoom background
        const scale = 1.1 + p * 0.1;
        const dw = W * scale, dh = H * scale;
        ctx.filter = 'blur(12px) brightness(0.35)';
        ctx.drawImage(img, -(dw - W) / 2, -(dh - H) / 2, dw, dh);
        ctx.filter = 'none';
    } else {
        const grad = ctx.createLinearGradient(0, 0, W, H);
        grad.addColorStop(0, adjustColor(THEME.background, 15));
        grad.addColorStop(1, THEME.background);
        ctx.fillStyle = grad;
        ctx.fillRect(0, 0, W, H);
    }

    // Overlay with gradient for depth
    const ov = ctx.createLinearGradient(0, 0, 0, H);
    ov.addColorStop(0, 'rgba(0,0,0,0.3)');
    ov.addColorStop(0.5, 'rgba(0,0,0,0.6)');
    ov.addColorStop(1, 'rgba(0,0,0,0.4)');
    ctx.fillStyle = ov;
    ctx.fillRect(0, 0, W, H);

    // Featured image (sharp, centered, with border)
    if (img) {
        const alpha = ease(Math.min(1, p * 3));
        ctx.globalAlpha = alpha;
        const imgW = 400, imgH = 250;
        const ix = W / 2 - imgW / 2, iy = 80;
        ctx.shadowColor = 'rgba(0,0,0,0.5)';
        ctx.shadowBlur = 20;
        roundRect(ix - 4, iy - 4, imgW + 8, imgH + 8, 12);
        ctx.fillStyle = THEME.primary;
        ctx.fill();
        ctx.shadowBlur = 0;
        ctx.save();
        roundRect(ix, iy, imgW, imgH, 10);
        ctx.clip();
        ctx.drawImage(img, ix, iy, imgW, imgH);
        ctx.restore();
        ctx.globalAlpha = 1;
    }

    // Title text
    const offsetY = Math.max(0, (1 - p * 2) * 40);
    const alpha = ease(Math.min(1, p * 2));
    ctx.globalAlpha = alpha;
    const titleY = img ? 420 : H / 2 - 20;

    ctx.fillStyle = THEME.text;
    ctx.font = `bold 58px ${THEME.fontHeading}`;
    ctx.textAlign = 'center';
    ctx.textBaseline = 'middle';
    ctx.shadowColor = 'rgba(0,0,0,0.8)';
    ctx.shadowBlur = 12;
    wrapText(scene.title, W / 2, titleY + offsetY, W - 180, 68);
    ctx.shadowBlur = 0;

    // Accent underline
    ctx.fillStyle = THEME.primary;
    const bw = 100 * alpha;
    ctx.fillRect(W / 2 - bw / 2, titleY + 60 + offsetY, bw, 3);

    // Watermark
    ctx.font = `20px ${THEME.fontBody}`;
    ctx.fillStyle = hexToRgba(THEME.text, 0.5);
    ctx.textAlign = 'left';
    ctx.fillText(scene.siteName, 30, H - 30);
    ctx.globalAlpha = 1;
}

function drawContent(p, scene, img) {
    if (img) {
        // Ken Burns with better quality
        const scale = 1.05 + p * 0.12;
        const dw = W * scale;
        const ratio = img.height / img.width;
        const dh = Math.max(H * scale, dw * ratio);
        const dx = -(dw - W) / 2 + Math.sin(p * 1.5) * 15;
        const dy = -(dh - H) / 2;
        ctx.drawImage(img, dx, dy, dw, dh);

        // Gradient overlay (top clear, bottom dark for text)
        const ov = ctx.createLinearGradient(0, 0, 0, H);
        ov.addColorStop(0, 'rgba(0,0,0,0.15)');
        ov.addColorStop(0.5, 'rgba(0,0,0,0.3)');
        ov.addColorStop(0.75, 'rgba(0,0,0,0.7)');
        ov.addColorStop(1, 'rgba(0,0,0,0.85)');
        ctx.fillStyle = ov;
        ctx.fillRect(0, 0, W, H);
    } else {
        // Dynamic colored gradient
        const hue1 = (scene.sceneNumber * 35 + 220) % 360;
        const hue2 = (hue1 + 25) % 360;
        const grad = ctx.createLinearGradient(0, 0, W, H);
        grad.addColorStop(0, `hsl(${hue1}, 35%, 12%)`);
        grad.addColorStop(1, `hsl(${hue2}, 45%, 20%)`);
        ctx.fillStyle = grad;
        ctx.fillRect(0, 0, W, H);

        // Decorative circles
        for (let i = 0; i < 5; i++) {
            ctx.beginPath();
            const cx = 100 + i * 280, cy = 150 + Math.sin(p * 2 + i) * 40;
            ctx.arc(cx, cy, 60 + Math.sin(i) * 30, 0, Math.PI * 2);
            ctx.fillStyle = `hsla(${hue1}, 50%, 40%, 0.08)`;
            ctx.fill();
        }
    }

    // Scene badge
    ctx.fillStyle = hexToRgba(THEME.primary, 0.9);
    roundRect(30, 25, 130, 40, 20);
    ctx.fill();
    ctx.fillStyle = '#fff';
    ctx.font = `bold 16px ${THEME.fontBody}`;
    ctx.textAlign = 'center';
    ctx.textBaseline = 'middle';
    ctx.fillText(`Scene ${scene.sceneNumber} / ${scene.totalScenes}`, 95, 46);

    // Site watermark
    ctx.font = `16px ${THEME.fontBody}`;
    ctx.fillStyle = hexToRgba(THEME.text, 0.45);
    ctx.textAlign = 'right';
    ctx.fillText(scene.siteName, W - 30, 46);

    // Text box
    const boxH = 200, boxY = H - boxH - 25;
    // Glassmorphism-style box
    ctx.fillStyle = 'rgba(0, 0, 0, 0.65)';
    roundRect(35, boxY, W - 70, boxH, 14);
    ctx.fill();
    // Top accent line
    ctx.fillStyle = THEME.primary;
    ctx.fillRect(35, boxY, W - 70, 3);

    // Typewriter text
    const chars = Math.floor(ease(Math.min(1, p * 1.3)) * scene.text.length);
    const vis = scene.text.substring(0, chars);
    ctx.fillStyle = THEME.text;
    ctx.font = `26px ${THEME.fontBody}`;
    ctx.textAlign = 'left';
    ctx.textBaseline = 'top';
    wrapTextLeft(vis, 60, boxY + 22, W - 140, 36);

    // Blinking cursor
    if (chars < scene.text.length && Math.sin(p * 20) > 0) {
        const cursorX = 60 + ctx.measureText(vis.split('\n').pop() || '').width;
        ctx.fillStyle = THEME.accent;
        ctx.fillRect(Math.min(cursorX, W - 80), boxY + 22, 2, 28);
    }
}

function drawTakeaway(p, scene) {
    const grad = ctx.createRadialGradient(W / 2, H / 2, 0, W / 2, H / 2, W * 0.7);
    grad.addColorStop(0, THEME.secondary);
    grad.addColorStop(1, adjustColor(THEME.secondary, -50));
    ctx.fillStyle = grad;
    ctx.fillRect(0, 0, W, H);

    // Decorative pattern
    ctx.globalAlpha = 0.06;
    for (let i = 0; i < 8; i++) {
        ctx.beginPath();
        ctx.arc(W / 2 + Math.cos(i * 0.8) * 200, H / 2 + Math.sin(i * 0.8) * 150, 80 + i * 20, 0, Math.PI * 2);
        ctx.strokeStyle = '#fff';
        ctx.lineWidth = 1;
        ctx.stroke();
    }
    ctx.globalAlpha = 1;

    // Big quote
    ctx.fillStyle = 'rgba(255,255,255,0.1)';
    ctx.font = 'bold 280px Georgia, serif';
    ctx.textAlign = 'center';
    ctx.textBaseline = 'middle';
    ctx.fillText('\u201C', W / 2 - 200, H / 2 - 60);

    const alpha = ease(Math.min(1, p * 2.5));
    ctx.globalAlpha = alpha;
    ctx.fillStyle = '#fff';
    ctx.font = `bold 34px ${THEME.fontHeading}`;
    ctx.textAlign = 'center';
    ctx.shadowColor = 'rgba(0,0,0,0.3)';
    ctx.shadowBlur = 8;
    wrapText(scene.text, W / 2, H / 2, W - 200, 46);
    ctx.shadowBlur = 0;

    // Label
    ctx.font = `18px ${THEME.fontBody}`;
    ctx.fillStyle = 'rgba(255,255,255,0.65)';
    ctx.fillText('\u2014 Key Takeaway \u2014', W / 2, H - 70);
    ctx.fillText(scene.siteName, W / 2, H - 42);
    ctx.globalAlpha = 1;
}

function drawOutro(p, scene) {
    const grad = ctx.createRadialGradient(W / 2, H / 2, 0, W / 2, H / 2, W * 0.8);
    grad.addColorStop(0, adjustColor(THEME.background, 35));
    grad.addColorStop(1, THEME.background);
    ctx.fillStyle = grad;
    ctx.fillRect(0, 0, W, H);

    // Subtle star field
    for (let i = 0; i < 80; i++) {
        const sx = (Math.sin(i * 7.3) * 0.5 + 0.5) * W;
        const sy = (Math.cos(i * 4.1) * 0.5 + 0.5) * H;
        const brightness = 0.1 + Math.sin(p * 3 + i) * 0.1;
        ctx.beginPath();
        ctx.arc(sx, sy, 1.5, 0, Math.PI * 2);
        ctx.fillStyle = hexToRgba(THEME.text, brightness);
        ctx.fill();
    }

    const alpha = ease(Math.min(1, p * 2));
    ctx.globalAlpha = alpha;

    ctx.fillStyle = THEME.text;
    ctx.font = `bold 50px ${THEME.fontHeading}`;
    ctx.textAlign = 'center';
    ctx.textBaseline = 'middle';
    ctx.fillText('Thanks for Watching!', W / 2, H / 2 - 90);

    // Divider
    ctx.fillStyle = THEME.primary;
    ctx.fillRect(W / 2 - 80, H / 2 - 40, 160, 3);

    ctx.font = `28px ${THEME.fontBody}`;
    ctx.fillStyle = hexToRgba(THEME.primary, 0.85);
    wrapText('\u201C' + scene.title + '\u201D', W / 2, H / 2 + 10, W - 200, 36);

    ctx.font = `bold 26px ${THEME.fontBody}`;
    ctx.fillStyle = THEME.accent;
    ctx.fillText('Read the full article at', W / 2, H / 2 + 80);

    ctx.font = `bold 30px ${THEME.fontHeading}`;
    ctx.fillStyle = THEME.text;
    ctx.fillText(scene.siteUrl, W / 2, H / 2 + 120);

    ctx.font = `18px ${THEME.fontBody}`;
    ctx.fillStyle = hexToRgba(THEME.text, 0.35);
    ctx.fillText('\u00A9 ' + scene.siteName, W / 2, H - 35);
    ctx.globalAlpha = 1;
}

// ========== FADE TRANSITION ==========
function drawFade(fadeProgress) {
    ctx.fillStyle = `rgba(0, 0, 0, ${fadeProgress})`;
    ctx.fillRect(0, 0, W, H);
}

// ========== MAIN GENERATE ==========

async function generate() {
    log('Building storyline...');
    const scenes = buildStoryline();

    // Load images
    log('Loading images...');
    const imageMap = new Map();
    for (const s of scenes) {
        if (s.image) {
            const img = await loadImage(s.image);
            if (img) imageMap.set(s.image, img);
            else s.image = null;
        }
    }

    // Pollinations fallback
    for (const scene of scenes) {
        if (scene.type === 'content' && !scene.image) {
            const kw = scene.text.split(' ').filter(w => w.length > 3).slice(0, 5).join(' ');
            if (kw) {
                log(`AI image for scene ${scene.sceneNumber}...`);
                const polUrl = `https://image.pollinations.ai/prompt/${encodeURIComponent(kw + ' cinematic professional')}?width=1280&height=720&nologo=true`;
                const img = await loadImage(polUrl);
                if (img) { scene.image = polUrl; imageMap.set(polUrl, img); }
            }
        }
    }

    // Total
    const FADE_FRAMES = Math.floor(FPS * 0.5); // 0.5s fade between scenes
    let totalDuration = scenes.reduce((s, sc) => s + sc.duration, 0);
    const totalFrames = totalDuration * FPS;

    // Start music
    log('Starting music...');
    let musicStream = null;
    try { musicStream = createBackgroundMusic(totalDuration + 2); }
    catch (e) { console.warn('Music failed:', e); }

    log('Recording video...');
    const canvasStream = canvas.captureStream(FPS);

    // Combine canvas video + audio into one stream
    const combinedTracks = [...canvasStream.getTracks()];
    if (musicStream) combinedTracks.push(...musicStream.getAudioTracks());
    const finalStream = new MediaStream(combinedTracks);

    const recorder = new MediaRecorder(finalStream, {
        mimeType: 'video/webm; codecs=vp8,opus',
        videoBitsPerSecond: 4000000,
        audioBitsPerSecond: 128000,
    });
    const chunks = [];
    recorder.ondataavailable = e => { if (e.data.size > 0) chunks.push(e.data); };
    recorder.start(200);

    const startTime = performance.now();
    let frameIndex = 0;
    const frameInterval = 1000 / FPS;

    for (let si = 0; si < scenes.length; si++) {
        const scene = scenes[si];
        const sceneFrames = scene.duration * FPS;
        const img = scene.image ? imageMap.get(scene.image) : null;
        const label = SCENE_LABELS[scene.type] || scene.type;

        if (sceneLabelEl) sceneLabelEl.textContent = `Scene ${si + 1}/${scenes.length}: ${label}`;

        for (let f = 0; f < sceneFrames; f++) {
            const p = f / sceneFrames;

            ctx.clearRect(0, 0, W, H);
            ctx.globalAlpha = 1;
            ctx.shadowBlur = 0;
            ctx.textAlign = 'center';
            ctx.textBaseline = 'middle';

            switch (scene.type) {
                case 'brand_intro': drawBrandIntro(p, scene); break;
                case 'title_card': drawTitleCard(p, scene, img); break;
                case 'content': drawContent(p, scene, img); break;
                case 'takeaway': drawTakeaway(p, scene); break;
                case 'outro': drawOutro(p, scene); break;
            }

            // Fade in at scene start
            if (f < FADE_FRAMES) {
                drawFade(1 - f / FADE_FRAMES);
            }
            // Fade out at scene end
            if (f > sceneFrames - FADE_FRAMES) {
                drawFade((f - (sceneFrames - FADE_FRAMES)) / FADE_FRAMES);
            }

            frameIndex++;

            // Update UI every 12 frames
            if (frameIndex % 12 === 0) {
                const pct = Math.round((frameIndex / totalFrames) * 100);
                if (progressBar) progressBar.value = pct;
                if (percentEl) percentEl.textContent = `${pct}%`;
                const elapsed = (performance.now() - startTime) / 1000;
                const rate = frameIndex / elapsed;
                const rem = Math.ceil((totalFrames - frameIndex) / rate);
                if (etaEl) etaEl.textContent = rem > 1 ? `~${rem}s remaining` : 'Finishing...';
                log(`${pct}% \u2014 ${label}`);
            }

            // Use setTimeout for reliable pacing (doesn't pause when tab loses focus)
            await new Promise(r => setTimeout(r, frameInterval));
        }
    }

    // Hold + finalize
    await new Promise(r => setTimeout(r, 500));
    recorder.stop();
    log('Finalizing...');

    // Stop music
    if (audioCtx) { try { audioCtx.close(); } catch (e) { } audioCtx = null; }

    await new Promise(r => { recorder.onstop = r; });

    currentBlob = new Blob(chunks, { type: 'video/webm' });
    const sizeMB = (currentBlob.size / 1024 / 1024).toFixed(1);
    const dur = Math.round(scenes.reduce((s, sc) => s + sc.duration, 0));
    log(`\u2705 Done! ${dur}s video (${sizeMB} MB)`);

    // Show preview
    if (previewPlayer) previewPlayer.src = URL.createObjectURL(currentBlob);
    if (previewSection) previewSection.style.display = 'block';
    if (progressContainer) progressContainer.style.display = 'none';
    if (btn) btn.style.display = 'none';
}

async function uploadVideo() {
    if (!currentBlob) return;
    log('\u{1F4E4} Uploading...');
    if (progressContainer) progressContainer.style.display = 'block';
    const fd = new FormData();
    fd.append('action', 'btv_upload_video');
    fd.append('nonce', btvData.nonce);
    fd.append('post_id', btvData.post_id);
    fd.append('video', currentBlob, 'blog-video-' + btvData.post_id + '.webm');
    try {
        const res = await fetch(btvData.ajaxurl, { method: 'POST', body: fd });
        const json = await res.json();
        if (json.success) { log('\u2705 Uploaded!'); setTimeout(() => location.reload(), 1500); }
        else throw new Error(json.data || 'Failed');
    } catch (e) { log('\u274C ' + e.message); }
}

function downloadVideo() {
    if (!currentBlob) return;
    const a = document.createElement('a');
    a.href = URL.createObjectURL(currentBlob);
    a.download = `blog-video-${btvData.post_id}.webm`;
    a.click();
}

function resetUI() {
    if (previewSection) previewSection.style.display = 'none';
    if (progressContainer) progressContainer.style.display = 'none';
    if (btn) { btn.style.display = 'block'; btn.disabled = false; }
    currentBlob = null;
}

// ========== EVENTS ==========

if (btn) {
    btn.addEventListener('click', async () => {
        if (!confirm('Generate video from this post?\n\nIncludes: Intro \u2192 Title \u2192 Content \u2192 Takeaway \u2192 Outro\nWith background music!')) return;
        btn.disabled = true;
        if (progressContainer) progressContainer.style.display = 'block';
        if (previewSection) previewSection.style.display = 'none';
        log('Starting...');
        try { await generate(); }
        catch (e) { console.error(e); log('\u274C ' + e.message); btn.disabled = false; }
    });
}

if (uploadBtn) uploadBtn.addEventListener('click', uploadVideo);
if (downloadBtn) downloadBtn.addEventListener('click', downloadVideo);
if (regenerateBtn) regenerateBtn.addEventListener('click', () => { resetUI(); btn.click(); });
