=== Blog to Video Converter ===
Contributors: antigravity
Tags: video, blog to video, ai, content repurposing, artificial intelligence
Requires at least: 6.0
Tested up to: 6.4
Stable tag: 2.7
License: GPLv2 or later

Turn your blog posts into engaging videos in seconds with AI-generated visuals, charts, and music.

== Description ==

**Blog to Video Converter** instantly transforms your written content into short, social-media-ready videos. It analyzes your post content, images, and data tables to generate a storyboard, complete with:

*   **🎬 Dynamic Visuals**: Uses your own images or fetches relevant stock media (Pexels/Pixabay).
*   **🎹 Smart Audio**: Auto-generates background music based on the mood of your text (Upbeat, Cinematic, Relaxed, etc.).
*   **📊 Data Visualization**: Automatically turns HTML tables and stats into animated bar and pie charts.
*   **📈 Built-in Analytics**: Track how many people watch, finish, and click through your videos with the dashboard.

**Key Features:**
*   **One-Click Generation**: Just click "Generate Video" on any post edit screen.
*   **Stock Media Integration**: Connect Pexels or Pixabay to fill in visual gaps.
*   **Smart Storyboard**: Automatically creates Intro, Content, Chart, Takeaway, and Outro scenes.
*   **Video Analytics**: Track Views, Plays, Completions, and CTA Clicks.
*   **No External Dependencies**: All video rendering happens in your browser (Canvas API).

== Installation ==

1.  Upload the plugin files to the `/wp-content/plugins/blog-to-video-converter` directory, or install the plugin through the WordPress plugins screen directly.
2.  Activate the plugin through the 'Plugins' screen in WordPress.
3.  Go to **Settings -> Blog to Video** to configure options.

== How to Use ==

1.  **Configure API Keys (Optional but Recommended)**:
    *   Go to **Settings -> Blog to Video**.
    *   Enter your **Pexels API Key** and/or **Pixabay API Key**.
    *   *Why?* If your blog post doesn't have many images, the plugin will use these keys to find high-quality stock videos and photos matching your content.
    *   Get keys here: [Pexels API](https://www.pexels.com/api/) | [Pixabay API](https://pixabay.com/api/docs/)

2.  **Generate a Video**:
    *   Open any Post or Page in the WordPress Editor.
    *   Look for the **"🎬 Blog to Video"** box in the sidebar (right side).
    *   Click the **Generate Video** button.
    *   Wait for the process to complete (usually 10-20 seconds).
    *   Preview the video and click **"Use This Video"** to save it.

3.  **View Analytics**:
    *   Go to **Video Analytics** in the main admin menu.
    *   See how your videos are performing!

== Frequently Asked Questions ==

= Why is the video generation slow? =
The video is rendered entirely in your browser to avoid server costs. Performance depends on your computer's speed. We are constantly optimizing the engine.

= Where do I get API keys? =
*   **Pexels**: Sign up at https://www.pexels.com/api/
*   **Pixabay**: Sign up at https://pixabay.com/api/docs/
Both are free!

= Can I edit the video? =
Currently, the video is auto-generated based on your content. You can "Regenerate" to get a slightly different result. Manual editing features are coming soon.
