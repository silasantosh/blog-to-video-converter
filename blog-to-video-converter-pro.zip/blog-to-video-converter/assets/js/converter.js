import { pipeline, env } from 'https://cdn.jsdelivr.net/npm/@xenova/transformers@2.14.0';
import { FFmpeg } from 'https://unpkg.com/@ffmpeg/ffmpeg@0.12.10/dist/esm/index.js';
import { fetchFile, toBlobURL } from 'https://unpkg.com/@ffmpeg/util@0.12.1/dist/esm/index.js';

env.allowLocalModels = false;
env.useBrowserCache = true;

const canvas = document.getElementById('btv-canvas');
const ctx = canvas ? canvas.getContext('2d') : null;
const width = canvas ? canvas.width : 1280;
const height = canvas ? canvas.height : 720;
const FPS = 30;

let ffmpeg = null;
let summarizer = null;
let synthesizer = null;
const HAS_HEADERS = window.crossOriginIsolated;

// UI Elements
const btn = document.getElementById('btv-generate-btn');
const progressContainer = document.getElementById('btv-progress-container');
const status = document.getElementById('btv-status');
const progressBar = document.getElementById('btv-progress');

// --- MEDIA FETCHER ---
class MediaFetcher {
    constructor() {
        this.pexelsKey = btvData.api_keys.pexels;
        this.pixabayKey = btvData.api_keys.pixabay;
        this.localImages = [btvData.post_image, ...(btvData.content_images || [])].filter(Boolean);
        this.usedIndices = new Set();
    }

    async getMediaForKeyword(keyword) {
        // 1. Try Pexels Video (Highest Priority)
        if (this.pexelsKey) {
            try {
                const vid = await this.fetchPexelsVideo(keyword);
                if (vid) return { type: 'video', url: vid };
            } catch (e) { console.warn('Pexels fail', e); }
        }

        // 2. Try Pixabay Video
        if (this.pixabayKey) {
            try {
                const vid = await this.fetchPixabayVideo(keyword);
                if (vid) return { type: 'video', url: vid };
            } catch (e) { console.warn('Pixabay fail', e); }
        }

        // 3. Fallback to Image (Local or AI)
        // Flip a coin to use local vs AI if local exists
        if (this.localImages.length > 0 && Math.random() > 0.3) {
            // Get random unused local image
            let idx = Math.floor(Math.random() * this.localImages.length);
            return { type: 'image', url: this.localImages[idx] };
        }

        // 4. Pollinations AI Image (Ultimate Fallback)
        const aiUrl = `https://image.pollinations.ai/prompt/${encodeURIComponent(keyword)}?width=1280&height=720&nologo=true`;
        return { type: 'image', url: aiUrl };
    }

    async fetchPexelsVideo(query) {
        const url = `https://api.pexels.com/videos/search?query=${encodeURIComponent(query)}&per_page=1&orientation=landscape&size=medium`;
        const res = await fetch(url, { headers: { Authorization: this.pexelsKey } });
        const data = await res.json();
        if (data.videos && data.videos.length > 0) {
            // Find a suitable video file (hd)
            const videoFile = data.videos[0].video_files.find(f => f.height >= 720) || data.videos[0].video_files[0];
            return videoFile.link;
        }
        return null;
    }

    async fetchPixabayVideo(query) {
        const url = `https://pixabay.com/api/videos/?key=${this.pixabayKey}&q=${encodeURIComponent(query)}`;
        const res = await fetch(url);
        const data = await res.json();
        if (data.hits && data.hits.length > 0) {
            return data.hits[0].videos.medium.url;
        }
        return null;
    }
}

function log(msg, error = false) {
    console.log(msg);
    if (status) {
        status.textContent = (error ? 'Error: ' : '') + msg;
        status.style.color = error ? 'red' : '#2271b1';
    }
}

if (btn) {
    btn.addEventListener('click', async () => {
        if (!confirm('Start video generation? This runs locally using AI.')) return;
        btn.disabled = true;
        progressContainer.style.display = 'block';

        try {
            await startProcess();
        } catch (e) {
            console.error(e);
            log(e.message, true);
            btn.disabled = false;
        }
    });
}

// Global Media Cache
const mediaCache = [];

async function startProcess() {
    const fetcher = new MediaFetcher();

    // 1. AI Summarize
    log('Summarizing Content...');
    if (!summarizer) summarizer = await pipeline('summarization', 'Xenova/distilbart-cnn-6-6');

    let content = btvData.post_content_full.substring(0, 3000);
    const summary = await summarizer(content, { max_new_tokens: 150 });
    const scriptText = summary[0].summary_text;
    log('Script: ' + scriptText.substring(0, 50) + '...');

    // 2. Generate Audio (or fallback)
    log('Generating Audio...');
    let audioBuffer = null;
    if (HAS_HEADERS) {
        try {
            if (!synthesizer) synthesizer = await pipeline('text-to-speech', 'Xenova/speecht5_tts', { quantized: false });
            const speaker = 'https://huggingface.co/datasets/Xenova/transformers.js-docs/resolve/main/speaker_embeddings.bin';
            const result = await synthesizer(scriptText, { speaker_embeddings: speaker });
            audioBuffer = result.audio;
        } catch (e) { log('TTS Skipped: ' + e.message); }
    }

    // 3. Pre-fetch Media based on keywords
    log('Fetching Visuals...');
    // Simple keyword extraction (every 5th word or split by sentence topics)
    const keywords = scriptText.split(' ').filter(w => w.length > 5).slice(0, 10); // pick top long words

    // Divide script into scenes (approx 5 seconds each)
    let totalDuration = audioBuffer ? (audioBuffer.length / 16000) : (scriptText.split(' ').length / 2.5);
    totalDuration += 6; // Intro/Outro

    const sceneCount = Math.ceil(totalDuration / 5);

    for (let i = 0; i < sceneCount; i++) {
        const keyword = keywords[i % keywords.length] || btvData.post_title;
        const media = await fetcher.getMediaForKeyword(keyword);

        // Load the media object (Image or Video Element)
        let element;
        if (media.type === 'video') {
            element = document.createElement('video');
            element.muted = true;
            element.crossOrigin = 'anonymous';
            element.src = media.url;
            await new Promise((r, j) => {
                element.onloadeddata = r;
                element.onerror = () => r(null); // Fallback if fails
            });
        } else {
            element = await loadImage(media.url).catch(() => null);
        }

        if (element) {
            mediaCache.push({ ...media, element });
        }
    }

    // Fallback if no media found
    if (mediaCache.length === 0 && btvData.post_image) {
        const img = await loadImage(btvData.post_image);
        mediaCache.push({ type: 'image', element: img });
    }

    // 4. Render
    if (HAS_HEADERS) {
        await renderFull(scriptText, audioBuffer, totalDuration);
    } else {
        await renderBasic(scriptText, totalDuration);
    }
}

async function renderFull(text, audioBuffer, duration) {
    if (!ffmpeg) {
        ffmpeg = new FFmpeg();
        const baseURL = 'https://unpkg.com/@ffmpeg/core@0.12.6/dist/esm';
        await ffmpeg.load({
            coreURL: await toBlobURL(`${baseURL}/ffmpeg-core.js`, 'text/javascript'),
            wasmURL: await toBlobURL(`${baseURL}/ffmpeg-core.wasm`, 'application/wasm'),
        });
    }

    let hasAudio = false;
    if (audioBuffer) {
        const wav = encodeWAV(audioBuffer, 16000);
        await ffmpeg.writeFile('audio.wav', wav);
        hasAudio = true;
    }

    const totalFrames = Math.ceil(duration * FPS);

    for (let i = 0; i < totalFrames; i++) {
        drawFrame(i, duration, text);

        const blob = await new Promise(r => canvas.toBlob(r, 'image/jpeg', 0.8));
        const buf = await blob.arrayBuffer();
        await ffmpeg.writeFile(`frame_${i.toString().padStart(5, '0')}.jpg`, new Uint8Array(buf));

        if (i % 30 === 0) {
            progressBar.value = (i / totalFrames) * 100;
            log(`Rendering ${i}/${totalFrames}`);
            await new Promise(r => setTimeout(r, 0));
        }
    }

    log('Encoding MP4...');
    const args = ['-framerate', '30', '-i', 'frame_%05d.jpg'];
    if (hasAudio) args.push('-i', 'audio.wav');
    args.push('-c:v', 'libx264', '-pix_fmt', 'yuv420p', '-preset', 'ultrafast', '-shortest', 'output.mp4');

    await ffmpeg.exec(args);
    const data = await ffmpeg.readFile('output.mp4');
    await uploadVideo(new Blob([data.buffer], { type: 'video/mp4' }), 'ai-video.mp4');
}

async function renderBasic(text, duration) {
    const stream = canvas.captureStream(FPS);
    const recorder = new MediaRecorder(stream, { mimeType: 'video/webm' });
    const chunks = [];
    recorder.ondataavailable = e => chunks.push(e.data);
    recorder.start();

    const totalFrames = Math.ceil(duration * FPS);
    for (let i = 0; i < totalFrames; i++) {
        drawFrame(i, duration, text);
        if (i % 30 === 0) {
            progressBar.value = (i / totalFrames) * 100;
            log(`Recording ${i}/${totalFrames}`);
            await new Promise(r => setTimeout(r, 0));
        }
        await new Promise(r => requestAnimationFrame(r));
    }

    recorder.stop();
    await new Promise(r => recorder.onstop = r);
    await uploadVideo(new Blob(chunks, { type: 'video/webm' }), 'video.webm');
}

function drawFrame(frame, duration, text) {
    const time = frame / FPS;

    // Clean
    ctx.fillStyle = '#000';
    ctx.fillRect(0, 0, width, height);

    if (time < 3) {
        // Intro
        drawTitle(btvData.post_title);
    } else if (time < duration - 3) {
        // Scenes
        const sceneTime = time - 3;
        const sceneIdx = Math.floor(sceneTime / 5) % mediaCache.length;
        const media = mediaCache[sceneIdx];

        if (media) {
            if (media.type === 'video') {
                // Determine video time
                const vid = media.element;
                const vidDuration = vid.duration || 10;
                vid.currentTime = (sceneTime % vidDuration);

                // Draw Video cover
                const aspect = vid.videoWidth / vid.videoHeight;
                const canvasAspect = width / height;
                let dw = width, dh = height;
                if (aspect > canvasAspect) dw = height * aspect;
                else dh = width / aspect;
                const dx = (width - dw) / 2;
                const dy = (height - dh) / 2;

                ctx.drawImage(vid, dx, dy, dw, dh);
            } else {
                // Ken Burns Image
                const img = media.element;
                const scale = 1 + ((sceneTime % 5) * 0.05);
                const dw = width * scale;
                const dh = (width / img.width * img.height) * scale;
                const dx = -(dw - width) / 2;
                const dy = -(dh - height) / 2;
                ctx.drawImage(img, dx, dy, dw, dh);
            }
        }

        // Text Overlay (Word Highlight)
        ctx.fillStyle = 'rgba(0,0,0,0.6)';
        ctx.fillRect(0, height - 150, width, 150);
        ctx.fillStyle = '#fff';
        ctx.font = '28px Arial';
        ctx.textAlign = 'center';

        // Simple scrolling text
        const words = text.split(' ');
        const wpm = 150 / 60; // 2.5 words per sec
        const currentWordIdx = Math.floor((time - 3) * wpm);
        const start = Math.max(0, currentWordIdx - 8);
        const end = currentWordIdx + 8;
        const chunk = words.slice(start, end).join(' ');

        ctx.fillText(chunk, width / 2, height - 80);

    } else {
        // Outro
        ctx.fillStyle = '#111';
        ctx.fillRect(0, 0, width, height);
        ctx.fillStyle = '#fff';
        ctx.font = 'bold 50px Arial';
        ctx.textAlign = 'center';
        ctx.fillText("Thanks for watching!", width / 2, height / 2);

        ctx.font = '30px Arial';
        ctx.fillStyle = '#ffcc00';
        ctx.fillText("Read more on our blog", width / 2, height / 2 + 60);
    }
}

function drawTitle(title) {
    const grad = ctx.createLinearGradient(0, 0, width, height);
    grad.addColorStop(0, '#1a2a6c');
    grad.addColorStop(1, '#b21f1f');
    ctx.fillStyle = grad;
    ctx.fillRect(0, 0, width, height);

    ctx.fillStyle = '#fff';
    ctx.font = 'bold 70px Arial';
    ctx.textAlign = 'center';
    ctx.textBaseline = 'middle';
    ctx.shadowColor = 'rgba(0,0,0,0.5)';
    ctx.shadowBlur = 10;

    // Word wrap title
    const words = title.split(' ');
    let line = '', lines = [], y = height / 2;
    for (let w of words) {
        if (ctx.measureText(line + w).width > width - 200) {
            lines.push(line); line = w + ' ';
        } else line += w + ' ';
    }
    lines.push(line);

    y -= (lines.length * 40);
    lines.forEach((l, i) => ctx.fillText(l, width / 2, y + (i * 80)));

    ctx.shadowBlur = 0;
}

async function uploadVideo(blob, filename) {
    const formData = new FormData();
    formData.append('action', 'btv_upload_video');
    formData.append('nonce', btvData.nonce);
    formData.append('post_id', btvData.post_id);
    formData.append('video', blob, filename);
    await fetch(btvData.ajaxurl, { method: 'POST', body: formData });
    log('Done! Reloading...');
    setTimeout(() => location.reload(), 1500);
}

async function loadImage(url) {
    return new Promise((resolve, reject) => {
        const img = new Image();
        img.crossOrigin = 'anonymous';
        img.onload = () => resolve(img);
        img.onerror = reject;
        img.src = url;
    });
}

function encodeWAV(samples, sampleRate) {
    const buffer = new ArrayBuffer(44 + samples.length * 2);
    const view = new DataView(buffer);
    writeString(view, 0, 'RIFF');
    view.setUint32(4, 36 + samples.length * 2, true);
    writeString(view, 8, 'WAVE');
    writeString(view, 12, 'fmt ');
    view.setUint32(16, 16, true);
    view.setUint16(20, 1, true);
    view.setUint16(22, 1, true);
    view.setUint32(24, sampleRate, true);
    view.setUint32(28, sampleRate * 2, true);
    view.setUint16(32, 2, true);
    view.setUint16(34, 16, true);
    writeString(view, 36, 'data');
    view.setUint32(40, samples.length * 2, true);
    floatTo16BitPCM(view, 44, samples);
    return new Uint8Array(buffer);
}

function floatTo16BitPCM(output, offset, input) {
    for (let i = 0; i < input.length; i++, offset += 2) {
        const s = Math.max(-1, Math.min(1, input[i]));
        output.setInt16(offset, s < 0 ? s * 0x8000 : s * 0x7FFF, true);
    }
}

function writeString(view, offset, string) {
    for (let i = 0; i < string.length; i++) {
        view.setUint8(offset + i, string.charCodeAt(i));
    }
}
