jQuery(document).ready(function($) {
    const canvas = document.getElementById('btv-canvas');
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    const width = canvas.width;
    const height = canvas.height;
    
    // Configuration
    const FPS = 30;
    const SCENE_DURATION = 3000; // 3 seconds per scene
    const TRANSITION_DURATION = 1000; // 1 second
    
    $('#btv-generate-btn').on('click', async function() {
        if (!confirm('This will generate a video from the post content. This requires the browser tab to remain active. Proceed?')) {
            return;
        }

        const btn = $(this);
        const progressContainer = $('#btv-progress-container');
        const status = $('#btv-status');
        const progressBar = $('#btv-progress');

        btn.prop('disabled', true);
        progressContainer.show();
        status.text('Preparing assets...');

        try {
            // Asset Loading
            const title = btvData.post_title;
            const excerpt = btvData.post_excerpt;
            const imageUrl = btvData.post_image;

            let mainImage = null;
            if (imageUrl) {
                try {
                    mainImage = await loadImage(imageUrl);
                } catch (e) {
                    console.warn('Could not load featured image, using placeholder color.');
                }
            }

            // Start Recording
            const stream = canvas.captureStream(FPS);
            const recorder = new MediaRecorder(stream, { mimeType: 'video/webm; codecs=vp9' });
            const chunks = [];

            recorder.ondataavailable = e => chunks.push(e.data);
            recorder.start();

            // --- Animation Sequence ---
            
            // 1. Title Scene
            status.text('Rendering Title Scene...');
            const titleFrames = (SCENE_DURATION / 1000) * FPS;
            for (let i = 0; i < titleFrames; i++) {
                drawTitleScene(ctx, width, height, title, i, titleFrames);
                progressBar.val((i / titleFrames) * 33);
                await nextFrame();
            }

            // 2. Image Scene
            status.text('Rendering Image Scene...');
            const imageFrames = (SCENE_DURATION / 1000) * FPS;
            for (let i = 0; i < imageFrames; i++) {
                drawImageScene(ctx, width, height, mainImage, title, i, imageFrames);
                progressBar.val(33 + (i / imageFrames) * 33);
                await nextFrame();
            }

            // 3. Outro/Excerpt Scene
            status.text('Rendering Outro Scene...');
            const outroFrames = (SCENE_DURATION / 1000) * FPS;
            for (let i = 0; i < outroFrames; i++) {
                drawOutroScene(ctx, width, height, excerpt, i, outroFrames);
                progressBar.val(66 + (i / outroFrames) * 33);
                await nextFrame();
            }

            // Stop Recording
            recorder.stop();
            status.text('Finalizing video...');
            
            // Wait for stop event
            await new Promise(resolve => recorder.onstop = resolve);

            // Upload
            const blob = new Blob(chunks, { type: 'video/webm' });
            status.text('Uploading to Media Library...');
            
            await uploadVideo(blob);

            status.text('Done! Refreshing page...');
            setTimeout(() => location.reload(), 1500);

        } catch (error) {
            console.error(error);
            status.text('Error: ' + error.message);
            btn.prop('disabled', false);
        }
    });

    const nextFrame = () => new Promise(resolve => requestAnimationFrame(resolve));

    const loadImage = (url) => {
        return new Promise((resolve, reject) => {
            const img = new Image();
            img.crossOrigin = "anonymous"; // Important for canvas export
            img.onload = () => resolve(img);
            img.onerror = reject;
            img.src = url;
            // Handle CORS proxy if needed in real production, but for local/same-origin WP it's usually fine
        });
    };

    // Drawing Functions
    function drawBackground(ctx, w, h, color) {
        ctx.fillStyle = color;
        ctx.fillRect(0, 0, w, h);
    }

    function drawTitleScene(ctx, w, h, text, frame, totalFrames) {
        const progress = frame / totalFrames;
        
        // Dynamic background
        const hue = (progress * 50) % 360;
        drawBackground(ctx, w, h, `hsl(${hue}, 60%, 20%)`);

        ctx.fillStyle = '#ffffff';
        ctx.font = 'bold 80px Arial';
        ctx.textAlign = 'center';
        ctx.textBaseline = 'middle';
        
        // Simple zoom effect
        const scale = 1 + (progress * 0.2);
        ctx.save();
        ctx.translate(w/2, h/2);
        ctx.scale(scale, scale);
        wrapText(ctx, text, 0, 0, w - 200, 90);
        ctx.restore();
    }

    function drawImageScene(ctx, w, h, image, text, frame, totalFrames) {
        drawBackground(ctx, w, h, '#111');
        
        if (image) {
            const aspect = image.width / image.height;
            const drawW = w;
            const drawH = w / aspect;
            const y = (h - drawH) / 2;
            ctx.drawImage(image, 0, y, drawW, drawH);
        }

        // Overlay with text
        ctx.fillStyle = 'rgba(0, 0, 0, 0.5)';
        ctx.fillRect(0, h - 200, w, 200);

        ctx.fillStyle = '#fff';
        ctx.font = '50px Arial';
        ctx.textAlign = 'center';
        ctx.fillText(text, w/2, h - 100);
    }

    function drawOutroScene(ctx, w, h, text, frame, totalFrames) {
         drawBackground(ctx, w, h, '#2a2a2a');
         
         ctx.fillStyle = '#fff';
         ctx.font = '40px Arial';
         ctx.textAlign = 'center';
         ctx.textBaseline = 'middle';
         
         wrapText(ctx, text, w/2, h/2, w - 300, 60);

         // Brand
         ctx.font = 'bold 30px Arial';
         ctx.fillStyle = '#ffcc00';
         ctx.fillText("Read more at our blog", w/2, h - 50);
    }

    // Helper for wrapping text
    function wrapText(ctx, text, x, y, maxWidth, lineHeight) {
        const words = text.split(' ');
        let line = '';
        const lines = [];

        for(let n = 0; n < words.length; n++) {
            const testLine = line + words[n] + ' ';
            const metrics = ctx.measureText(testLine);
            const testWidth = metrics.width;
            if (testWidth > maxWidth && n > 0) {
                lines.push(line);
                line = words[n] + ' ';
            } else {
                line = testLine;
            }
        }
        lines.push(line);

        // Draw lines centered vertically around y
        const totalHeight = lines.length * lineHeight;
        let startY = y - (totalHeight / 2) + (lineHeight / 2);

        for (let k = 0; k < lines.length; k++) {
             ctx.fillText(lines[k], x, startY + (k * lineHeight));
        }
    }

    async function uploadVideo(blob) {
        const formData = new FormData();
        formData.append('action', 'btv_upload_video');
        formData.append('nonce', btvData.nonce);
        formData.append('post_id', btvData.post_id);
        formData.append('video', blob, 'blog-video-' + btvData.post_id + '.webm');

        return $.ajax({
            url: btvData.ajaxurl,
            type: 'POST',
            data: formData,
            processData: false,
            contentType: false
        });
    }
});
