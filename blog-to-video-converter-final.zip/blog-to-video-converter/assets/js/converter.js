/**
 * Blog to Video Converter v1.0.0
 * Speed optimized, enhanced audio, debuggable stock media.
 */

const canvas = document.getElementById('btv-canvas');
if (!canvas) throw new Error('Canvas not found');
const ctx = canvas.getContext('2d');
// v5.0.0: HD Retina Rendering (1080p)
canvas.width = 1920; canvas.height = 1080;
const W = canvas.width, H = canvas.height, FPS = 30;

const btn = document.getElementById('btv-generate-btn');
const progressContainer = document.getElementById('btv-progress-container');
const statusEl = document.getElementById('btv-status');
const sceneLabelEl = document.getElementById('btv-scene-label');
const progressBar = document.getElementById('btv-progress');
const percentEl = document.getElementById('btv-percent');
const etaEl = document.getElementById('btv-eta');
const previewSection = document.getElementById('btv-preview-section');
const previewPlayer = document.getElementById('btv-preview-player');
const uploadBtn = document.getElementById('btv-upload-btn');
const downloadBtn = document.getElementById('btv-download-btn');
const regenerateBtn = document.getElementById('btv-regenerate-btn');

let currentBlob = null;
function log(msg) { console.log('[BTV]', msg); if (statusEl) statusEl.textContent = msg; }

// ========== THEME ==========
const ts = (typeof btvData !== 'undefined' && btvData.theme_style) ? btvData.theme_style : {};
function cleanFont(r) { return r ? r.replace(/var\([^)]+\)/g, '').replace(/["']/g, '').trim() : ''; }
const T = {
    pri: ts.primary || '#6c63ff', sec: ts.secondary || '#ff6b6b',
    acc: ts.accent || '#ffcc00', bg: ts.background || '#0f0c29',
    txt: ts.text || '#ffffff',
    fH: cleanFont(ts.fontHeading) || 'Inter, "Segoe UI Emoji", Arial, sans-serif',
    fB: cleanFont(ts.fontBody) || 'Inter, "Segoe UI Emoji", Arial, sans-serif',
};
const CHART_COLORS = ['#6c63ff', '#ff6b6b', '#ffcc00', '#2ed573', '#1e90ff', '#ff6348', '#a29bfe', '#55efc4'];

function adj(hex, a) {
    hex = hex.replace('#', ''); if (hex.length === 3) hex = hex.split('').map(c => c + c).join('');
    let r = parseInt(hex.substr(0, 2), 16) || 0, g = parseInt(hex.substr(2, 2), 16) || 0, b = parseInt(hex.substr(4, 2), 16) || 0;
    return `rgb(${Math.min(255, Math.max(0, r + a))},${Math.min(255, Math.max(0, g + a))},${Math.min(255, Math.max(0, b + a))})`;
}
function rgba(hex, a) {
    hex = hex.replace('#', ''); if (hex.length === 3) hex = hex.split('').map(c => c + c).join('');
    return `rgba(${parseInt(hex.substr(0, 2), 16) || 0},${parseInt(hex.substr(2, 2), 16) || 0},${parseInt(hex.substr(4, 2), 16) || 0},${a})`;
}
function ease(t) { return t < 0.5 ? 2 * t * t : 1 - Math.pow(-2 * t + 2, 2) / 2; }

const LABELS = {
    brand_intro: '🏠 Intro', title_card: '📰 Title', content: '📝 Content',
    image_slide: '🖼️ Image', bar_chart: '📊 Bar Chart', pie_chart: '📈 Pie Chart',
    takeaway: '💡 Takeaway', outro: '👋 Outro', heading: '🏷️ Heading', list: '📋 List'
};

// ========== MUSIC GENERATOR (IMPROVED) ==========
let audioCtx = null, musicDest = null;
function createMusic(dur, mood = 'ambient') {
    audioCtx = new (window.AudioContext || window.webkitAudioContext)();
    musicDest = audioCtx.createMediaStreamDestination();
    const master = audioCtx.createGain();
    master.gain.setValueAtTime(0.15, audioCtx.currentTime); // Slightly louder
    master.connect(musicDest);
    const now = audioCtx.currentTime;

    // Faster tempos, brighter tones
    const configs = {
        'upbeat': { tempo: 0.2, notes: [261.63, 329.63, 392, 523.25, 587.33, 783.99], type: 'square', arpSpeed: 0.12, chance: 0.4 },
        'cinematic': { tempo: 1.0, notes: [196, 261.63, 311.13, 392, 523.25], type: 'sawtooth', arpSpeed: 0.3, chance: 0.3 },
        'relaxing': { tempo: 1.5, notes: [261.63, 329.63, 392, 493.88], type: 'sine', arpSpeed: 0.4, chance: 0.3 },
        'tech': { tempo: 0.15, notes: [220, 261.63, 329.63, 440, 523.25], type: 'triangle', arpSpeed: 0.1, chance: 0.5 },
        'ambient.mp3': { tempo: 0.8, notes: [261.63, 329.63, 392, 440, 523.25], type: 'sine', arpSpeed: 0.25, chance: 0.3 }
    };

    let mKey = mood.replace('.mp3', '').toLowerCase();
    if (!configs[mKey]) mKey = 'ambient.mp3';
    const C = configs[mKey];

    // Pad / Chords
    for (let i = 0; i < C.notes.length; i++) {
        const o = audioCtx.createOscillator(), g = audioCtx.createGain();
        o.type = C.type === 'square' ? 'triangle' : 'sine';
        o.frequency.setValueAtTime(C.notes[i], now);

        const lfo = audioCtx.createOscillator(), lg = audioCtx.createGain();
        lfo.type = 'sine'; lfo.frequency.setValueAtTime(0.1 + i * 0.05, now); lg.gain.setValueAtTime(2, now);
        lfo.connect(lg); lg.connect(o.frequency); lfo.start(now); lfo.stop(now + dur + 1);

        g.gain.setValueAtTime(0, now); g.gain.linearRampToValueAtTime(0.04, now + 2 + i * 0.5);
        g.gain.setValueAtTime(0.04, now + dur - 3); g.gain.linearRampToValueAtTime(0, now + dur);

        o.connect(g); g.connect(master); o.start(now + i * 0.3); o.stop(now + dur + 1);
    }

    // Arpeggios / Melody
    const steps = Math.floor(dur / C.arpSpeed);
    for (let i = 0; i < steps; i++) {
        if (Math.random() < C.chance) {
            const t = now + i * C.arpSpeed;
            const note = C.notes[Math.floor(Math.random() * C.notes.length)] * (Math.random() > 0.8 ? 2 : 1);

            const osc = audioCtx.createOscillator(), env = audioCtx.createGain();
            osc.type = C.type;
            osc.frequency.setValueAtTime(note, t);

            env.gain.setValueAtTime(0, t);
            env.gain.linearRampToValueAtTime(0.04, t + 0.03); // Faster attack
            env.gain.exponentialRampToValueAtTime(0.001, t + C.arpSpeed * 0.8); // Faster decay

            osc.connect(env); env.connect(master);
            osc.start(t); osc.stop(t + C.arpSpeed);
        }
    }

    return musicDest.stream;
}

// ========== AI SUMMARIZER (v5.0.0) ==========
async function aiSummarize(text) {
    log('AI is distilling your blog...');
    const groqKey = btvData.api_keys?.groq;
    const prompt = `Summarize this blog post into 5 punchy cinematic sentences for a video. Each sentence should be a high-impact insight. Format: Just the sentences, no numbers.\n\nBlog Content:\n${text.substring(0, 4000)}`;

    try {
        if (groqKey) {
            log('Using Groq Llama-3 (High Speed)...');
            const r = await fetch('https://api.groq.com/openai/v1/chat/completions', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json', 'Authorization': `Bearer ${groqKey}` },
                body: JSON.stringify({ messages: [{ role: 'user', content: prompt }], model: 'llama3-8b-8192', temperature: 0.5 })
            });
            const d = await r.json();
            const content = d.choices?.[0]?.message?.content;
            if (content) return cleanLines(content);
        }

        // Fallback to Pollinations (GET for stability)
        log('Using Free AI Support...');
        const r = await Promise.race([
            fetch(`https://text.pollinations.ai/${encodeURIComponent(prompt)}`),
            new Promise((_, rej) => setTimeout(() => rej(new Error('AI Timeout')), 5000))
        ]);
        const d = await r.text();
        if (d) return cleanLines(d);
    } catch (e) { log('AI unavailable, using standard extraction.'); }
    return null;
}

function cleanLines(d) {
    return d.split('\n').filter(l => l.trim().length > 10).map(l => l.replace(/^[-*•]\s*/, '').trim());
}

// ========== HELPERS ==========
function wrapT(t, x, y, mw, lh) { const w = t.split(' '); let l = ''; const ls = []; for (const v of w) { const tt = l + v + ' '; if (ctx.measureText(tt).width > mw && l) { ls.push(l.trim()); l = v + ' '; } else l = tt; } ls.push(l.trim()); const sy = y - ((ls.length - 1) * lh) / 2; for (let i = 0; i < ls.length; i++)ctx.fillText(ls[i], x, sy + i * lh); }
function wrapL(t, x, y, mw, lh) { const w = t.split(' '); let l = '', ly = y; for (const v of w) { const tt = l + v + ' '; if (ctx.measureText(tt).width > mw && l) { ctx.fillText(l.trim(), x, ly); l = v + ' '; ly += lh; } else l = tt; } ctx.fillText(l.trim(), x, ly); }
function rr(x, y, w, h, r) {
    ctx.beginPath(); ctx.moveTo(x + r, y); ctx.lineTo(x + w - r, y); ctx.quadraticCurveTo(x + w, y, x + w, y + r);
    ctx.lineTo(x + w, y + h - r); ctx.quadraticCurveTo(x + w, y + h, x + w - r, y + h);
    ctx.lineTo(x + r, y + h); ctx.quadraticCurveTo(x, y + h, x, y + h - r);
    ctx.lineTo(x, y + r); ctx.quadraticCurveTo(x, y, x + r, y); ctx.closePath();
}
// v5.0.0: Glassmorphism Helper
function glass(x, y, w, h, r = 20) {
    ctx.save();
    ctx.fillStyle = 'rgba(255,255,255,0.08)';
    ctx.shadowColor = 'rgba(0,0,0,0.4)'; ctx.shadowBlur = 40;
    rr(x, y, w, h, r); ctx.fill();
    ctx.strokeStyle = 'rgba(255,255,255,0.15)'; ctx.lineWidth = 1.5; ctx.stroke();
    ctx.restore();
}

// v5.0.0: Visual Effects (Vignette & Particles)
function postProcess() {
    const v = ctx.createRadialGradient(W / 2, H / 2, W * 0.2, W / 2, H / 2, W * 0.9);
    v.addColorStop(0, 'rgba(0,0,0,0)'); v.addColorStop(1, 'rgba(0,0,0,0.5)');
    ctx.fillStyle = v; ctx.fillRect(0, 0, W, H);
}

const particles = Array.from({ length: 40 }, () => ({
    x: Math.random() * W, y: Math.random() * H,
    s: 1 + Math.random() * 3, o: 0.1 + Math.random() * 0.3,
    vx: (Math.random() - 0.5) * 0.5, vy: (Math.random() - 0.5) * 0.5
}));
function drawParticles() {
    ctx.save();
    particles.forEach(p => {
        p.x = (p.x + p.vx + W) % W; p.y = (p.y + p.vy + H) % H;
        ctx.beginPath(); ctx.arc(p.x, p.y, p.s, 0, Math.PI * 2);
        ctx.fillStyle = rgba('#ffffff', p.o); ctx.fill();
    });
    ctx.restore();
}
function loadImg(u) { return new Promise(r => { if (!u) return r(null); const i = new Image(); i.crossOrigin = 'anonymous'; i.onload = () => r(i); i.onerror = () => r(null); i.src = u; }); }

// ========== STORYLINE (FASTER PACING) ==========
function buildStoryline() {
    const sc = [], site = btvData.site_name || 'Our Website', url = btvData.site_url || '', desc = btvData.site_description || '',
        title = btvData.post_title || 'Untitled', exc = btvData.post_excerpt || '',
        rawScenes = btvData.scenes || [], imgs = [btvData.post_image, ...(btvData.content_images || [])].filter(Boolean),
        stats = btvData.stats || [], type = btvData.primary_type || 'article', data = btvData.schema_data || {};

    // --- CINEMATIC RULE 5: COLD OPEN HOOK ---
    // Start with a high-impact hook instead of an intro.
    sc.push({ type: 'hook', duration: 2.5, text: title, image: imgs[0], siteName: site });

    // --- CINEMATIC RULE 2/7: NARRATIVE FLOW (5 Cs) ---
    // Context
    sc.push({ type: 'context', duration: 4.5, text: exc || 'In this article, we dive deep into...', image: imgs[0], siteName: site });

    // Body (Conflict & Solution / Schema Aware)
    if (type === 'recipe' && data.ingredients) {
        sc.push({ type: 'ingredients', duration: 6, items: data.ingredients, siteName: site });
        rawScenes.forEach((s, i) => {
            if (s.text.length > 10) sc.push({ ...s, type: 'step', duration: 4, stepNum: i + 1, siteName: site, image: imgs[(i + 1) % imgs.length] });
        });
    } else if (type === 'product') {
        sc.push({ type: 'product_spotlight', duration: 5, text: exc, price: data.price, rating: data.rating, image: imgs[1] || imgs[0], siteName: site });
        // Middle: Conflict/Problem (The Challenge)
        if (rawScenes[0]) sc.push({ ...rawScenes[0], duration: 5, type: 'conflict', siteName: site });
        // Middle: Solution (Why this product)
        rawScenes.slice(1, 4).forEach(s => sc.push({ ...s, duration: 4, siteName: site }));
    } else if (type === 'faq' && data.qa) {
        data.qa.forEach(item => sc.push({ type: 'qa', duration: 5, q: item.q, a: item.a, siteName: site }));
    } else {
        // Standard Narrative Flow
        rawScenes.forEach((s, i) => {
            // CINEMATIC RULE 8: VARIED PACING
            let dur = (i === 1) ? 6 : 4.5; // Conflict/Middle gets more time
            sc.push({ ...s, duration: dur, siteName: site, image: imgs[i % imgs.length] });
        });
    }

    // --- CINEMATIC RULE 9: CALL TO ACTION ---
    sc.push({ type: 'brand_intro', duration: 3, siteName: site, siteDesc: desc, siteUrl: url }); // Branding moved here
    sc.push({ type: 'outro', duration: 4, siteName: site, siteUrl: url, title });

    // --- CINEMATIC RULE 3: CONCISENESS ---
    // Hard-cap at 90 seconds
    let currentDur = 0;
    const finalSc = [];
    for (const s of sc) {
        if (currentDur + s.duration > 90) break;
        finalSc.push(s);
        currentDur += s.duration;
    }

    return finalSc;
}

// ========== SCENE RENDERERS (Same as before) ==========
function drawBrandIntro(p, s) {
    const g = ctx.createRadialGradient(W / 2, H / 2, 0, W / 2, H / 2, W * 0.8);
    g.addColorStop(0, adj(T.bg, 40)); g.addColorStop(1, T.bg); ctx.fillStyle = g; ctx.fillRect(0, 0, W, H);
    for (let i = 0; i < 50; i++) {
        const a = p * 2 + i * 0.7, r = 150 + Math.sin(i * 0.5) * 250;
        ctx.beginPath(); ctx.arc(W / 2 + Math.cos(a) * r, H / 2 + Math.sin(a * 0.6) * r * 0.5, 2 + Math.sin(i) * 1.5, 0, Math.PI * 2);
        ctx.fillStyle = rgba(T.pri, 0.08 + Math.sin(p * 3 + i) * 0.06); ctx.fill();
    }
    ctx.beginPath(); ctx.arc(W / 2, H / 2, 180 + Math.sin(p * 3) * 20, 0, Math.PI * 2);
    ctx.strokeStyle = rgba(T.pri, 0.15 * ease(p)); ctx.lineWidth = 2; ctx.stroke();
    const al = ease(Math.min(1, p * 2.5)); ctx.globalAlpha = al;
    ctx.fillStyle = T.txt; ctx.font = `bold 76px ${T.fH}`; ctx.textAlign = 'center'; ctx.textBaseline = 'middle';
    ctx.shadowColor = rgba(T.pri, 0.6); ctx.shadowBlur = 30; ctx.fillText(s.siteName, W / 2, H / 2 - 35); ctx.shadowBlur = 0;
    const lw = 240 * al; ctx.fillStyle = T.pri; ctx.fillRect(W / 2 - lw / 2, H / 2 + 10, lw, 3);
    ctx.font = `26px ${T.fB}`; ctx.fillStyle = rgba(T.txt, 0.65); ctx.fillText(s.siteDesc, W / 2, H / 2 + 45);
    ctx.font = `18px ${T.fB}`; ctx.fillStyle = rgba(T.txt, 0.4); ctx.fillText(s.siteUrl, W / 2, H / 2 + 80); ctx.globalAlpha = 1;
}

function drawTitleCard(p, s, img) {
    if (img) { ctx.filter = 'blur(12px) brightness(0.35)'; const sc = 1.1 + p * 0.1, dw = W * sc, dh = H * sc; ctx.drawImage(img, -(dw - W) / 2, -(dh - H) / 2, dw, dh); ctx.filter = 'none'; }
    else { const g = ctx.createLinearGradient(0, 0, W, H); g.addColorStop(0, adj(T.bg, 15)); g.addColorStop(1, T.bg); ctx.fillStyle = g; ctx.fillRect(0, 0, W, H); }
    const ov = ctx.createLinearGradient(0, 0, 0, H); ov.addColorStop(0, 'rgba(0,0,0,0.3)'); ov.addColorStop(0.5, 'rgba(0,0,0,0.6)'); ov.addColorStop(1, 'rgba(0,0,0,0.4)'); ctx.fillStyle = ov; ctx.fillRect(0, 0, W, H);
    if (img) {
        const al = ease(Math.min(1, p * 3)); ctx.globalAlpha = al; const iw = 400, ih = 250, ix = W / 2 - iw / 2, iy = 80;
        ctx.shadowColor = 'rgba(0,0,0,0.5)'; ctx.shadowBlur = 20; rr(ix - 4, iy - 4, iw + 8, ih + 8, 12); ctx.fillStyle = T.pri; ctx.fill();
        ctx.shadowBlur = 0; ctx.save(); rr(ix, iy, iw, ih, 10); ctx.clip(); ctx.drawImage(img, ix, iy, iw, ih); ctx.restore(); ctx.globalAlpha = 1;
    }
    const oy = Math.max(0, (1 - p * 2) * 40), al = ease(Math.min(1, p * 2)), ty = img ? 420 : H / 2 - 20;
    ctx.globalAlpha = al; ctx.fillStyle = T.txt; ctx.font = `bold 58px ${T.fH}`; ctx.textAlign = 'center'; ctx.textBaseline = 'middle';
    ctx.shadowColor = 'rgba(0,0,0,0.8)'; ctx.shadowBlur = 12; wrapT(s.title, W / 2, ty + oy, W - 180, 68); ctx.shadowBlur = 0;
    ctx.fillStyle = T.pri; const bw = 100 * al; ctx.fillRect(W / 2 - bw / 2, ty + 60 + oy, bw, 3);
    ctx.font = `20px ${T.fB}`; ctx.fillStyle = rgba(T.txt, 0.5); ctx.textAlign = 'left'; ctx.fillText(s.siteName, 30, H - 30); ctx.globalAlpha = 1;
}

function drawImageSlide(p, s, img) {
    ctx.fillStyle = T.bg; ctx.fillRect(0, 0, W, H);
    if (!img) { drawContent(p, { ...s, type: 'content', text: s.caption || 'Image', sceneNumber: 1, totalScenes: 1 }, null); return; }
    const al = ease(Math.min(1, p * 2.5)); ctx.globalAlpha = al;
    const maxW = W - 160, maxH = H - 200; const ratio = Math.min(maxW / img.width, maxH / img.height, 1);
    const iw = img.width * ratio, ih = img.height * ratio; const ix = (W - iw) / 2, iy = 60;
    ctx.shadowColor = 'rgba(0,0,0,0.4)'; ctx.shadowBlur = 25; rr(ix - 5, iy - 5, iw + 10, ih + 10, 10); ctx.fillStyle = T.pri; ctx.fill(); ctx.shadowBlur = 0;
    ctx.save(); rr(ix, iy, iw, ih, 8); ctx.clip(); const scale = 1 + p * 0.05; const sw = iw * scale, sh = ih * scale; ctx.drawImage(img, ix - (sw - iw) / 2, iy - (sh - ih) / 2, sw, sh); ctx.restore();
    if (s.caption) { const captionY = iy + ih + 30; ctx.fillStyle = rgba(T.txt, 0.8); ctx.font = `italic 24px ${T.fB}`; ctx.textAlign = 'center'; ctx.textBaseline = 'top'; wrapT(s.caption, W / 2, captionY, W - 120, 32); }
    ctx.font = `16px ${T.fB}`; ctx.fillStyle = rgba(T.txt, 0.4); ctx.textAlign = 'right'; ctx.fillText(s.siteName, W - 30, H - 25); ctx.globalAlpha = 1;
}

function drawContent(p, s, img) {
    // Fill background if no zoomed layer drawn yet
    if (img && !(s.type === 'insight' || s.type === 'hook' || s.type === 'content')) {
        const sc = 1.05 + p * 0.1, dw = W * sc, r = img.height / img.width, dh = Math.max(H * sc, dw * r);
        ctx.drawImage(img, -(dw - W) / 2, -(dh - H) / 2, dw, dh);
        ctx.fillStyle = 'rgba(0,0,0,0.5)'; ctx.fillRect(0, 0, W, H);
    } else if (!img) {
        ctx.fillStyle = T.bg; ctx.fillRect(0, 0, W, H);
    }

    const al = ease(Math.min(1, p * 2)); ctx.globalAlpha = al;
    const txt = s.text || '';

    if (s.type === 'title' || s.type === 'hook') {
        // --- CINEMATIC RULE 4: HITCHCOCK RULE ---
        // Scale title/hook text larger as scene progresses for visual weight
        const hitchScale = 1 + p * 0.15;
        ctx.save();
        ctx.translate(W / 2, H / 2);
        ctx.scale(hitchScale, hitchScale);
        ctx.fillStyle = T.txt; ctx.font = `bold 64px ${T.fH}`; ctx.textAlign = 'center';
        wrapT(txt, 0, 0, (W - 200) / hitchScale, 72 / hitchScale);
        ctx.restore();
    } else if (s.type === 'heading') {
        ctx.fillStyle = T.acc; ctx.font = `bold 56px ${T.fH}`; ctx.textAlign = 'center';
        ctx.fillText('⭐', W / 2, H / 2 - 100 * al);
        wrapT(txt, W / 2, H / 2, W - 180, 64);
    } else if (s.type === 'list' || s.type === 'ingredients') {
        const items = s.items || [];
        const titleL = s.type === 'ingredients' ? '🍳 Ingredients' : '';
        if (titleL) { ctx.fillStyle = T.acc; ctx.font = `bold 32px ${T.fH}`; ctx.fillText(titleL, 150, H / 2 - (items.length * 35) - 40); }
        ctx.textAlign = 'left'; ctx.font = `32px ${T.fB}`; ctx.fillStyle = T.txt;
        items.forEach((item, i) => {
            const iy = H / 2 - (items.length * 30) + i * 55;
            const itemAl = ease(Math.min(1, Math.max(0, p * 3 - i * 0.3)));
            ctx.globalAlpha = itemAl;
            ctx.fillText((s.type === 'ingredients' ? '🛒 ' : '🔹 ') + item, 150 + (1 - itemAl) * 30, iy);
        });
    } else if (s.type === 'step') {
        ctx.fillStyle = T.pri; rr(50, 50, 160, 60, 30); ctx.fill();
        ctx.fillStyle = '#fff'; ctx.font = `bold 24px ${T.fB}`; ctx.textAlign = 'center'; ctx.fillText(`STEP ${s.stepNum}`, 130, 80);
        const bH = 200, bY = H - bH - 50; ctx.fillStyle = 'rgba(0,0,0,0.7)'; rr(40, bY, W - 80, bH, 20); ctx.fill();
        ctx.fillStyle = T.txt; ctx.font = `32px ${T.fB}`; ctx.textAlign = 'left'; wrapL(txt, 70, bY + 40, W - 140, 42);
        ctx.fillStyle = T.pri; ctx.fillRect(40, H - 10, (W - 80) * p, 10);
    } else if (s.type === 'product_spotlight') {
        const bH = 400, bY = H / 2 - bH / 2; ctx.fillStyle = 'rgba(0,0,0,0.6)'; rr(W / 2, bY, W / 2 - 40, bH, 20); ctx.fill();
        ctx.fillStyle = T.acc; ctx.font = `bold 72px ${T.fH}`; ctx.textAlign = 'left'; ctx.fillText(s.price, W / 2 + 50, bY + 100);
        ctx.fillStyle = '#ffcc00'; ctx.font = `32px ${T.fB}`; ctx.fillText('★ '.repeat(Math.round(s.rating)) + `(${s.rating})`, W / 2 + 50, bY + 160);
        ctx.fillStyle = '#fff'; ctx.font = `24px ${T.fB}`; wrapL(txt, W / 2 + 50, bY + 220, W / 2 - 120, 32);
    } else if (s.type === 'qa') {
        ctx.fillStyle = T.acc; ctx.font = `bold 36px ${T.fH}`; ctx.textAlign = 'left'; ctx.fillText('Q: ' + s.q, 80, 150 + (1 - al) * 20);
        ctx.fillStyle = '#fff'; ctx.font = `30px ${T.fB}`; wrapL('A: ' + s.a, 100, 220, W - 200, 40);
        ctx.strokeStyle = T.pri; ctx.lineWidth = 4; ctx.beginPath(); ctx.moveTo(80, 180); ctx.lineTo(W - 80, 180); ctx.stroke();
    } else {
        const bH = 320, bY = H - bH - 80;
        glass(80, bY, W - 160, bH, 25);
        ctx.fillStyle = T.txt; ctx.font = `42px ${T.fB}`; ctx.textAlign = 'left'; ctx.textBaseline = 'top';
        const ch = Math.floor(p * 1.5 * txt.length);
        wrapL(txt.substring(0, ch), 120, bY + 60, W - 240, 56);
    }

    ctx.globalAlpha = 1;
}

function drawBarChart(p, s) {
    const g = ctx.createLinearGradient(0, 0, W, H); g.addColorStop(0, adj(T.bg, 20)); g.addColorStop(1, T.bg); ctx.fillStyle = g; ctx.fillRect(0, 0, W, H);
    const data = s.data || [], n = data.length; if (n === 0) return;
    ctx.fillStyle = T.txt; ctx.font = `bold 36px ${T.fH}`; ctx.textAlign = 'center'; ctx.textBaseline = 'middle'; ctx.fillText(s.title || 'Data', W / 2, 50);
    const chartX = 120, chartY = 100, chartW = W - 240, chartH = H - 200;
    const barW = Math.min(80, (chartW / n) * 0.6), gap = (chartW - barW * n) / (n + 1), maxVal = Math.max(...data.map(d => d.value), 1);
    ctx.strokeStyle = rgba(T.txt, 0.2); ctx.lineWidth = 1; ctx.beginPath(); ctx.moveTo(chartX, chartY); ctx.lineTo(chartX, chartY + chartH); ctx.lineTo(chartX + chartW, chartY + chartH); ctx.stroke();
    for (let i = 0; i <= 4; i++) {
        const gy = chartY + chartH - (chartH * i / 4); ctx.beginPath(); ctx.moveTo(chartX, gy); ctx.lineTo(chartX + chartW, gy); ctx.strokeStyle = rgba(T.txt, 0.08); ctx.stroke();
        ctx.fillStyle = rgba(T.txt, 0.4); ctx.font = `14px ${T.fB}`; ctx.textAlign = 'right'; ctx.textBaseline = 'middle'; const gridVal = (maxVal * i / 4); ctx.fillText(gridVal > 1000 ? (gridVal / 1000).toFixed(1) + 'K' : gridVal.toFixed(0), chartX - 10, gy);
    }
    const animP = ease(Math.min(1, p * 1.8));
    for (let i = 0; i < n; i++) {
        const d = data[i], x = chartX + gap + i * (barW + gap), barH = (d.value / maxVal) * chartH * animP, y = chartY + chartH - barH;
        const bg = ctx.createLinearGradient(x, y, x, chartY + chartH); bg.addColorStop(0, CHART_COLORS[i % CHART_COLORS.length]); bg.addColorStop(1, adj(CHART_COLORS[i % CHART_COLORS.length], -40)); ctx.fillStyle = bg; rr(x, y, barW, barH, 4); ctx.fill();
        ctx.shadowColor = CHART_COLORS[i % CHART_COLORS.length]; ctx.shadowBlur = 10; rr(x, y, barW, 2, 1); ctx.fill(); ctx.shadowBlur = 0;
        ctx.fillStyle = T.txt; ctx.font = `bold 18px ${T.fB}`; ctx.textAlign = 'center'; ctx.textBaseline = 'bottom'; const vLabel = d.unit === '%' ? d.value.toFixed(0) + '%' : (d.value > 1000 ? (d.value / 1000).toFixed(1) + 'K' : d.value.toFixed(0)); if (animP > 0.3) ctx.fillText(vLabel, x + barW / 2, y - 8);
        ctx.fillStyle = rgba(T.txt, 0.75); ctx.font = `14px ${T.fB}`; ctx.textBaseline = 'top'; const lbl = d.label.length > 12 ? d.label.substring(0, 11) + '…' : d.label; ctx.fillText(lbl, x + barW / 2, chartY + chartH + 10);
    }
    ctx.font = `16px ${T.fB}`; ctx.fillStyle = rgba(T.txt, 0.35); ctx.textAlign = 'right'; ctx.textBaseline = 'middle'; ctx.fillText(s.siteName, W - 30, H - 25);
}

function drawPieChart(p, s) {
    const g = ctx.createLinearGradient(0, 0, W, H); g.addColorStop(0, adj(T.bg, 20)); g.addColorStop(1, T.bg); ctx.fillStyle = g; ctx.fillRect(0, 0, W, H);
    const data = s.data || []; if (data.length === 0) return;
    ctx.fillStyle = T.txt; ctx.font = `bold 36px ${T.fH}`; ctx.textAlign = 'center'; ctx.textBaseline = 'middle'; ctx.fillText(s.title || 'Distribution', W / 2, 45);
    const cx = W / 2 - 150, cy = H / 2 + 20, radius = Math.min(W, H) * 0.28, total = data.reduce((s, d) => s + d.value, 0) || 1, animP = ease(Math.min(1, p * 1.8)); let startAngle = -Math.PI / 2;
    for (let i = 0; i < data.length; i++) {
        const d = data[i], sliceAngle = (d.value / total) * Math.PI * 2 * animP;
        ctx.beginPath(); ctx.moveTo(cx, cy); ctx.arc(cx, cy, radius, startAngle, startAngle + sliceAngle); ctx.closePath(); ctx.fillStyle = CHART_COLORS[i % CHART_COLORS.length]; ctx.fill(); ctx.strokeStyle = 'rgba(0,0,0,0.3)'; ctx.lineWidth = 2; ctx.stroke();
        if (animP > 0.5) {
            const midAngle = startAngle + sliceAngle / 2, lx = cx + Math.cos(midAngle) * (radius + 25), ly = cy + Math.sin(midAngle) * (radius + 25);
            ctx.fillStyle = rgba(T.txt, 0.6); ctx.font = `14px ${T.fB}`; ctx.textAlign = midAngle > Math.PI / 2 || midAngle < -Math.PI / 2 ? 'right' : 'left'; ctx.fillText(`${d.value.toFixed(0)}%`, lx, ly);
        }
        startAngle += sliceAngle;
    }
    ctx.beginPath(); ctx.arc(cx, cy, radius * 0.5, 0, Math.PI * 2); ctx.fillStyle = T.bg; ctx.fill(); ctx.fillStyle = rgba(T.txt, 0.3); ctx.font = `bold 22px ${T.fH}`; ctx.textAlign = 'center'; ctx.textBaseline = 'middle'; ctx.fillText('Total', cx, cy - 10); ctx.fillStyle = T.txt; ctx.font = `bold 28px ${T.fH}`; ctx.fillText(total.toFixed(0) + (data[0]?.unit === '%' ? '%' : ''), cx, cy + 18);
    const legX = W / 2 + 80, legY = H / 2 - data.length * 20;
    for (let i = 0; i < data.length; i++) {
        const d = data[i], y = legY + i * 42;
        ctx.fillStyle = CHART_COLORS[i % CHART_COLORS.length]; rr(legX, y, 18, 18, 4); ctx.fill(); ctx.fillStyle = T.txt; ctx.font = `18px ${T.fB}`; ctx.textAlign = 'left'; ctx.textBaseline = 'middle'; ctx.fillText(d.label, legX + 28, y + 9);
    }
    ctx.font = `16px ${T.fB}`; ctx.fillStyle = rgba(T.txt, 0.35); ctx.textAlign = 'right'; ctx.fillText(s.siteName, W - 30, H - 25);
}

function drawTakeaway(p, s) {
    const g = ctx.createRadialGradient(W / 2, H / 2, 0, W / 2, H / 2, W * 0.7); g.addColorStop(0, T.sec); g.addColorStop(1, adj(T.sec, -50)); ctx.fillStyle = g; ctx.fillRect(0, 0, W, H);
    ctx.globalAlpha = 0.06; for (let i = 0; i < 8; i++) { ctx.beginPath(); ctx.arc(W / 2 + Math.cos(i * 0.8) * 200, H / 2 + Math.sin(i * 0.8) * 150, 80 + i * 20, 0, Math.PI * 2); ctx.strokeStyle = '#fff'; ctx.lineWidth = 1; ctx.stroke(); } ctx.globalAlpha = 1;
    ctx.fillStyle = 'rgba(255,255,255,0.1)'; ctx.font = 'bold 280px Georgia,serif'; ctx.textAlign = 'center'; ctx.textBaseline = 'middle'; ctx.fillText('\u201C', W / 2 - 200, H / 2 - 60);
    const al = ease(Math.min(1, p * 2.5)); ctx.globalAlpha = al; ctx.fillStyle = '#fff'; ctx.font = `bold 34px ${T.fH}`; ctx.textAlign = 'center'; ctx.shadowColor = 'rgba(0,0,0,0.3)'; ctx.shadowBlur = 8; wrapT(s.text, W / 2, H / 2, W - 200, 46); ctx.shadowBlur = 0;
    ctx.font = `18px ${T.fB}`; ctx.fillStyle = 'rgba(255,255,255,0.65)'; ctx.fillText('\u2014 Key Takeaway \u2014', W / 2, H - 70); ctx.fillText(s.siteName, W / 2, H - 42); ctx.globalAlpha = 1;
}

function drawOutro(p, s) {
    const g = ctx.createRadialGradient(W / 2, H / 2, 0, W / 2, H / 2, W * 0.8); g.addColorStop(0, adj(T.bg, 35)); g.addColorStop(1, T.bg); ctx.fillStyle = g; ctx.fillRect(0, 0, W, H);
    for (let i = 0; i < 80; i++) { ctx.beginPath(); ctx.arc((Math.sin(i * 7.3) * 0.5 + 0.5) * W, (Math.cos(i * 4.1) * 0.5 + 0.5) * H, 1.5, 0, Math.PI * 2); ctx.fillStyle = rgba(T.txt, 0.1 + Math.sin(p * 3 + i) * 0.1); ctx.fill(); }
    const al = ease(Math.min(1, p * 2)); ctx.globalAlpha = al; ctx.fillStyle = T.txt; ctx.font = `bold 50px ${T.fH}`; ctx.textAlign = 'center'; ctx.textBaseline = 'middle'; ctx.fillText('Thanks for Watching!', W / 2, H / 2 - 90); ctx.fillStyle = T.pri; ctx.fillRect(W / 2 - 80, H / 2 - 40, 160, 3);
    ctx.font = `28px ${T.fB}`; ctx.fillStyle = rgba(T.pri, 0.85); wrapT('\u201C' + s.title + '\u201D', W / 2, H / 2 + 10, W - 200, 36);
    ctx.font = `bold 26px ${T.fB}`; ctx.fillStyle = T.acc; ctx.fillText('Read the full article at', W / 2, H / 2 + 80); ctx.font = `bold 30px ${T.fH}`; ctx.fillStyle = T.txt; ctx.fillText(s.siteUrl, W / 2, H / 2 + 120);
    ctx.font = `18px ${T.fB}`; ctx.fillStyle = rgba(T.txt, 0.35); ctx.fillText('\u00A9 ' + s.siteName, W / 2, H - 35); ctx.globalAlpha = 1;
}

function drawFade(fp) { ctx.fillStyle = `rgba(0,0,0,${fp})`; ctx.fillRect(0, 0, W, H); }

// ========== GENERATE ==========
async function generate() {
    log('Analyzing content...');
    let rawText = btvData.post_content || '';
    let scenes = buildStoryline();

    // v6.0.0: Restore Media Engine Init
    if (window.BTVMediaEngine && btvData.api_keys) {
        window.BTVMediaEngine.init(btvData.api_keys);
        log('Media engine ready.');
    }

    // AI Summarization Enhancement
    if (rawText.length > 500) {
        const aiPoints = await aiSummarize(rawText);
        if (aiPoints && aiPoints.length >= 3) {
            log('AI Insights extracted. Optimizing storyboard...');
            // Re-map segments to AI insights
            const site = btvData.site_name || 'Our Website';
            const imgs = [btvData.post_image, ...(btvData.content_images || [])].filter(Boolean);
            const aiScenes = [
                { type: 'hook', duration: 3, text: btvData.post_title, image: imgs[0], siteName: site },
                ...aiPoints.map((text, i) => ({ type: 'insight', duration: 5, text, image: imgs[(i + 1) % imgs.length], siteName: site })),
                { type: 'outro', duration: 4, siteName: site, siteUrl: btvData.site_url, title: btvData.post_title }
            ];
            scenes = aiScenes;
        }
    }

    log('Building cinematic storyline...');
    const imgMap = new Map();

    // Determine Audio Mood
    let mood = 'ambient.mp3';
    if (window.BTVMediaEngine) {
        const fullText = btvData.post_title + ' ' + (btvData.post_excerpt || '');
        mood = window.BTVMediaEngine.selectAudioTrack(fullText);
        log(`Mood: ${mood.replace('.mp3', '')}`);
    }

    // Load Checks
    for (const s of scenes) {
        if (s.image) {
            const i = await loadImg(s.image);
            if (i) imgMap.set(s.image, i); else s.image = null;
        }

        // Stock Media Fallback
        if (s.type === 'content' && !s.image && window.BTVMediaEngine) {
            const kw = s.text.split(' ').filter(w => w.length > 5).slice(0, 3).join(' '); // Better kw quality
            if (kw) {
                log(`Fetching stock: ${kw}...`);
                const u = await window.BTVMediaEngine.getStockMedia(kw, 'image');
                if (u) {
                    const i = await loadImg(u);
                    if (i) { s.image = u; imgMap.set(u, i); }
                }
            }
        }

        // Pollinations Fallback
        if (s.type === 'content' && !s.image) {
            const kw = s.text.split(' ').filter(w => w.length > 4).slice(0, 5).join(' ');
            if (kw) {
                const u = `https://image.pollinations.ai/prompt/${encodeURIComponent(kw + ' cinematic')}?width=1280&height=720&nologo=true`;
                const i = await loadImg(u); if (i) { s.image = u; imgMap.set(u, i); }
            }
        }
    }

    const FADE = Math.floor(FPS * 0.5);
    let totDur = scenes.reduce((s, v) => s + v.duration, 0);
    const totFrames = totDur * FPS;

    log('Starting music...');
    let mStream = null;
    try { mStream = createMusic(totDur + 2, mood); } catch (e) { console.warn('Music:', e); }

    log('Recording...');
    const cStream = canvas.captureStream(FPS);
    const tracks = [...cStream.getTracks()];
    if (mStream) tracks.push(...mStream.getAudioTracks());
    const fStream = new MediaStream(tracks);

    // v6.0.0: Robust Recorder
    let rec;
    try {
        rec = new MediaRecorder(fStream, {
            mimeType: 'video/webm; codecs=vp8,opus',
            videoBitsPerSecond: 12000000
        });
    } catch (e) {
        log('HD fail, switching to standard SD...');
        rec = new MediaRecorder(fStream, { videoBitsPerSecond: 4000000 });
    }
    const chunks = []; rec.ondataavailable = e => { if (e.data.size > 0) chunks.push(e.data); }; rec.start(200);

    const t0 = performance.now(); let fi = 0; const fInt = 1000 / FPS;

    for (let si = 0; si < scenes.length; si++) {
        const s = scenes[si], sf = s.duration * FPS, img = s.image ? imgMap.get(s.image) : null;
        const lbl = LABELS[s.type] || s.type;
        if (sceneLabelEl) sceneLabelEl.textContent = `Scene ${si + 1}/${scenes.length}: ${lbl}`;

        for (let f = 0; f < sf; f++) {
            const p = f / sf; ctx.clearRect(0, 0, W, H); ctx.globalAlpha = 1; ctx.shadowBlur = 0; ctx.textAlign = 'center'; ctx.textBaseline = 'middle';

            // Background Layer
            if (img && (s.type === 'insight' || s.type === 'hook' || s.type === 'content')) {
                const sc = 1.1 + p * 0.1;
                ctx.save(); ctx.translate(W / 2, H / 2); ctx.scale(sc, sc);
                ctx.drawImage(img, -W / 2, -H / 2, W, H); ctx.restore();
                ctx.fillStyle = 'rgba(0,0,0,0.5)'; ctx.fillRect(0, 0, W, H);
            }

            drawParticles();

            switch (s.type) {
                case 'brand_intro': drawBrandIntro(p, s); break;
                case 'outro': drawOutro(p, s); break;
                case 'bar_chart': drawBarChart(p, s); break;
                case 'pie_chart': drawPieChart(p, s); break;
                case 'takeaway': drawTakeaway(p, s); break;
                default: drawContent(p, s, img); break;
            }

            postProcess();

            if (f < FADE) drawFade(1 - f / FADE);
            if (f > sf - FADE) drawFade((f - (sf - FADE)) / FADE);
            fi++;
            if (fi % 15 === 0) {
                const pc = Math.round(fi / totFrames * 100); if (progressBar) progressBar.value = pc; if (percentEl) percentEl.textContent = pc + '%';
                const el = (performance.now() - t0) / 1000, rt = fi / el, rm = Math.ceil((totFrames - fi) / rt);
                if (etaEl) etaEl.textContent = rm > 1 ? `~${rm}s left` : 'Finishing...'; log(`${pc}% \u2014 ${lbl}`);
            }
            await new Promise(r => setTimeout(r, fInt));
        }
    }
    await new Promise(r => setTimeout(r, 500)); rec.stop(); log('Finalizing...');
    if (audioCtx) { try { audioCtx.close(); } catch (e) { } audioCtx = null; }
    await new Promise(r => { rec.onstop = r; });

    currentBlob = new Blob(chunks, { type: 'video/webm' });
    const mb = (currentBlob.size / 1024 / 1024).toFixed(1);
    const dur = Math.round(scenes.reduce((s, v) => s + v.duration, 0));
    log(`\u2705 Done! ${dur}s video (${mb} MB)`);
    if (previewPlayer) previewPlayer.src = URL.createObjectURL(currentBlob);
    if (previewSection) previewSection.style.display = 'block';
    if (progressContainer) progressContainer.style.display = 'none';
    if (btn) btn.style.display = 'none';
}

async function upload() {
    if (!currentBlob) return; log('\u{1F4E4} Uploading...'); if (progressContainer) progressContainer.style.display = 'block';
    const fd = new FormData(); fd.append('action', 'btv_upload_video'); fd.append('nonce', btvData.nonce); fd.append('post_id', btvData.post_id);
    fd.append('video', currentBlob, 'blog-video-' + btvData.post_id + '.webm');
    try {
        const r = await fetch(btvData.ajaxurl, { method: 'POST', body: fd }); const j = await r.json();
        if (j.success) { log('\u2705 Uploaded!'); setTimeout(() => location.reload(), 1500); } else throw new Error(j.data || 'Failed');
    } catch (e) { log('\u274C ' + e.message); }
}

function download() { if (!currentBlob) return; const a = document.createElement('a'); a.href = URL.createObjectURL(currentBlob); a.download = `blog-video-${btvData.post_id}.webm`; a.click(); }
function resetUI() { if (previewSection) previewSection.style.display = 'none'; if (progressContainer) progressContainer.style.display = 'none'; if (btn) { btn.style.display = 'block'; btn.disabled = false; } currentBlob = null; }

if (btn) btn.addEventListener('click', async () => {
    if (!confirm('Generate video from this post?')) return;
    btn.disabled = true; if (progressContainer) progressContainer.style.display = 'block'; if (previewSection) previewSection.style.display = 'none';
    log('Starting...'); try { await generate(); } catch (e) { console.error(e); log('\u274C ' + e.message); btn.disabled = false; }
});
if (uploadBtn) uploadBtn.addEventListener('click', upload);
if (downloadBtn) downloadBtn.addEventListener('click', download);
if (regenerateBtn) regenerateBtn.addEventListener('click', () => { resetUI(); btn.click(); });
