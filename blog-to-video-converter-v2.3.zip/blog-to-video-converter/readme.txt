=== Blog to Video Converter ===
Contributors: antigravity
Tags: video, ai, content-to-video, text-to-speech, ffmpeg, pexels, pixabay
Requires at least: 6.0
Tested up to: 6.7
Stable tag: 1.2.0
License: GPLv2 or later
License URI: https://www.gnu.org/licenses/gpl-2.0.html

Turn blog posts into high-quality videos using AI and Stock Media (Pexels, Pixabay).

== Description ==

Turn your blog posts into engaging videos directly from your browser! This plugin uses advanced AI (Transformers.js) and WebAssembly (FFmpeg.wasm) to:

1.  **Summarize** your post content into a video script.
2.  **Generate Voiceover** using AI Text-to-Speech.
3.  **Fetch Stock Media**: Automatically finds relevant videos from **Pexels** or **Pixabay** (requires free API key), or uses AI-generated images from **Pollinations.ai** (free, no key).
4.  **Render Visuals**: Mixes stock video, your post images, and AI images with professional transitions.
5.  **Export as MP4** so you can share it anywhere.

**Privacy Focused**: All processing happens **locally** in your browser.

== Installation ==

1.  Upload the plugin files to the `/wp-content/plugins/blog-to-video-converter` directory.
2.  Activate the plugin through the 'Plugins' screen in WordPress.
3.  Go to **Settings > Blog to Video** to enter your optional API keys for Pexels/Pixabay.

== How to Use ==

1.  Go to **Posts** and edit any blog post.
2.  Look for the **Blog to Video** box.
3.  Click **Generate Video**.
4.  **Wait**: The first time you run it, it will download ~200MB of AI models.
5.  Once finished, the video will be attached to the top of your post.

== Advanced Features ==

*   **Pexels/Pixabay Integration**: Get real high-quality stock footage.
*   **Pollinations.ai**: Free AI images on the fly.
*   **Branding**: Support the creator links included.

== Changelog ==

= 1.2.0 =
*   Added Pexels and Pixabay integration.
*   Added Pollinations.ai fallback.
*   Added Author Branding and Settings Page.

= 1.1.0 =
*   Added AI Summarization and TTS.
*   Added MP4 export via FFmpeg.wasm.

= 1.0.0 =
*   Initial release.
