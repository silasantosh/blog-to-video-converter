import { pipeline, env } from 'https://cdn.jsdelivr.net/npm/@xenova/transformers@2.14.0';
import { FFmpeg } from 'https://unpkg.com/@ffmpeg/ffmpeg@0.12.10/dist/esm/index.js';
import { fetchFile, toBlobURL } from 'https://unpkg.com/@ffmpeg/util@0.12.1/dist/esm/index.js';

// Configure transformers env
env.allowLocalModels = false;
env.useBrowserCache = true;

const canvas = document.getElementById('btv-canvas');
const ctx = canvas ? canvas.getContext('2d') : null;
const width = canvas ? canvas.width : 1280;
const height = canvas ? canvas.height : 720;

// Config
const FPS = 30;

// State
let ffmpeg = null;
let summarizer = null;
let synthesizer = null;

// UI Elements
const btn = document.getElementById('btv-generate-btn');
const progressContainer = document.getElementById('btv-progress-container');
const status = document.getElementById('btv-status');
const progressBar = document.getElementById('btv-progress');

if (btn) {
    btn.addEventListener('click', async () => {
        if (!confirm('This process downloads ~200MB of AI models and runs in your browser. It may take a few minutes. Continue?')) {
            return;
        }

        btn.disabled = true;
        progressContainer.style.display = 'block';

        try {
            await startProcess();
        } catch (e) {
            console.error(e);
            status.textContent = 'Error: ' + e.message;
            btn.disabled = false;
        }
    });
}

async function startProcess() {
    // 1. Initialize AI Models
    status.textContent = 'Loading AI Models (Summarization & TTS)...';

    if (!summarizer) {
        // Use a smaller distilled model for speed
        summarizer = await pipeline('summarization', 'Xenova/distilbart-cnn-6-6');
    }

    // For TTS, we'll try a very lightweight approach or stick to silence + text if speecht5 is too heavy/complex for simple JS environment without detailed audio context handling.
    // However, user asked for AI features. Let's try speecht5.
    if (!synthesizer) {
        synthesizer = await pipeline('text-to-speech', 'Xenova/speecht5_tts', { quantized: false });
    }

    // 2. Generate Script
    status.textContent = 'Analyzing content...';
    let content = btvData.post_content_full;
    // Truncate if too long for model window
    if (content.length > 2000) content = content.substring(0, 2000);

    // Run summarization
    const summary = await summarizer(content, { max_new_tokens: 100 });
    const scriptText = summary[0].summary_text;
    console.log("Generated Script:", scriptText);

    // 3. Generate Audio
    status.textContent = 'Generating Voiceover...';
    let audioBuffer = null;
    try {
        // Load speaker embeddings from a URL (standard procedure for SpeechT5 JS)
        // Using a reliable source for embeddings or default
        const speaker_embeddings = 'https://huggingface.co/datasets/Xenova/transformers.js-docs/resolve/main/speaker_embeddings.bin';
        const result = await synthesizer(scriptText, { speaker_embeddings });
        audioBuffer = result.audio; // Float32Array
    } catch (e) {
        console.warn("TTS failed, proceeding without audio", e);
    }

    // 4. Load FFmpeg
    status.textContent = 'Loading Video Encoder...';
    if (!ffmpeg) {
        ffmpeg = new FFmpeg();
        const baseURL = 'https://unpkg.com/@ffmpeg/core@0.12.6/dist/esm';
        await ffmpeg.load({
            coreURL: await toBlobURL(`${baseURL}/ffmpeg-core.js`, 'text/javascript'),
            wasmURL: await toBlobURL(`${baseURL}/ffmpeg-core.wasm`, 'application/wasm'),
        });
    }

    // 5. Render Video Frames
    status.textContent = 'Rendering Visuals...';

    // Write audio to ffmpeg virtual fs if exists
    let hasAudio = false;
    if (audioBuffer) {
        // audioBuffer is Float32Array, need to convert to proper wav or raw pcm
        const wavData = encodeWAV(audioBuffer, 16000); // 16kHz is standard for SpeechT5
        await ffmpeg.writeFile('audio.wav', wavData);
        hasAudio = true;
    }

    // Determine duration
    let duration = 10; // default 10s
    if (audioBuffer) {
        duration = audioBuffer.length / 16000;
    } else {
        duration = Math.max(5, scriptText.split(' ').length / 2); // approx reading speed
    }

    // Add buffer for intro/outro
    duration += 4; // +2s intro, +2s outro

    const totalFrames = Math.ceil(duration * FPS);

    // Load Image
    let mainImage = null;
    if (btvData.post_image) {
        try {
            mainImage = await loadImage(btvData.post_image);
        } catch (e) {
            console.log("Failed to load image", e);
        }
    }

    // Render Loop
    for (let i = 0; i < totalFrames; i++) {
        const time = i / FPS;

        if (time < 2) {
            drawTitleScene(ctx, width, height, btvData.post_title, i);
        } else if (time < duration - 2) {
            // Main content with scrolling text
            drawMainScene(ctx, width, height, mainImage, scriptText, time - 2);
        } else {
            drawOutroScene(ctx, width, height, "Thanks for watching!");
        }

        // Capture frame
        // toBlob is async
        const blob = await new Promise(r => canvas.toBlob(r, 'image/jpeg', 0.8));
        const buff = await blob.arrayBuffer();
        const num = i.toString().padStart(5, '0');
        await ffmpeg.writeFile(`frame_${num}.jpg`, new Uint8Array(buff));

        if (i % 30 === 0) {
            progressBar.value = (i / totalFrames) * 100;
            status.textContent = `Rendering frame ${i}/${totalFrames}`;
            await new Promise(r => setTimeout(r, 0)); // Yield to UI
        }
    }

    // 6. Encode
    status.textContent = 'Encoding MP4 (FFmpeg)...';

    // FFMPEG Command
    // -framerate 30 -pattern_type glob -i '*.jpg' ...
    // Note: glob is not always available in ffmpeg.wasm minimal builds, use sequence pattern %05d

    const inputArgs = ['-framerate', '30', '-i', 'frame_%05d.jpg'];
    if (hasAudio) {
        inputArgs.push('-i', 'audio.wav');
    }

    const outputArgs = [
        '-c:v', 'libx264',
        '-pix_fmt', 'yuv420p',
        '-preset', 'ultrafast',
        '-shortest'
    ];

    await ffmpeg.exec([...inputArgs, ...outputArgs, 'output.mp4']);

    // 7. Upload
    status.textContent = 'Uploading...';
    const data = await ffmpeg.readFile('output.mp4');
    const videoBlob = new Blob([data.buffer], { type: 'video/mp4' });

    // Use the localized ajaxurl
    const formData = new FormData();
    formData.append('action', 'btv_upload_video');
    formData.append('nonce', btvData.nonce);
    formData.append('post_id', btvData.post_id);
    formData.append('video', videoBlob, 'ai-video.mp4');

    await fetch(btvData.ajaxurl, {
        method: 'POST',
        body: formData
    });

    status.textContent = 'Done! Reloading...';
    setTimeout(() => location.reload(), 1000);
}

// Helpers
function encodeWAV(samples, sampleRate) {
    const buffer = new ArrayBuffer(44 + samples.length * 2);
    const view = new DataView(buffer);

    // RIFF identifier
    writeString(view, 0, 'RIFF');
    // file length
    view.setUint32(4, 36 + samples.length * 2, true);
    // RIFF type
    writeString(view, 8, 'WAVE');
    // format chunk identifier
    writeString(view, 12, 'fmt ');
    // format chunk length
    view.setUint32(16, 16, true);
    // sample format (raw)
    view.setUint16(20, 1, true);
    // channel count
    view.setUint16(22, 1, true);
    // sample rate
    view.setUint32(24, sampleRate, true);
    // byte rate (sample rate * block align)
    view.setUint32(28, sampleRate * 2, true);
    // block align (channel count * bytes per sample)
    view.setUint16(32, 2, true);
    // bits per sample
    view.setUint16(34, 16, true);
    // data chunk identifier
    writeString(view, 36, 'data');
    // data chunk length
    view.setUint32(40, samples.length * 2, true);

    // Write samples
    floatTo16BitPCM(view, 44, samples);

    return new Uint8Array(buffer);
}

function floatTo16BitPCM(output, offset, input) {
    for (let i = 0; i < input.length; i++, offset += 2) {
        const s = Math.max(-1, Math.min(1, input[i]));
        output.setInt16(offset, s < 0 ? s * 0x8000 : s * 0x7FFF, true);
    }
}

function writeString(view, offset, string) {
    for (let i = 0; i < string.length; i++) {
        view.setUint8(offset + i, string.charCodeAt(i));
    }
}

function drawTitleScene(ctx, w, h, text, frame) {
    ctx.fillStyle = '#1a1a1a';
    ctx.fillRect(0, 0, w, h);
    ctx.fillStyle = '#fff';
    ctx.font = 'bold 60px Arial';
    ctx.textAlign = 'center';
    ctx.textBaseline = 'middle';
    ctx.fillText(text, w / 2, h / 2);
}

function drawMainScene(ctx, w, h, img, text, time) {
    ctx.fillStyle = '#000';
    ctx.fillRect(0, 0, w, h);

    if (img) {
        // Draw image with Ken Burns effect (simple pan/zoom)
        const scale = 1 + (time * 0.05);
        const dw = w * scale;
        const dh = (w / img.width * img.height) * scale;
        const dx = -(dw - w) / 2;
        const dy = -(dh - h) / 2;

        ctx.drawImage(img, dx, dy, dw, dh);
    }

    // Subtitle / Text overlay
    // Wrap text logic
    ctx.fillStyle = 'rgba(0,0,0,0.7)';
    ctx.fillRect(20, h - 200, w - 40, 180);
    ctx.fillStyle = '#fff';
    ctx.font = '30px Arial';
    ctx.textAlign = 'center';

    // Simple scrolling text or paginated text
    // We'll just show the whole summary for now in chunks if possible, or just the first few sentences
    // For this demo, let's just show the text static wrapped
    wrapText(ctx, text, w / 2, h - 150, w - 100, 40);
}

function drawOutroScene(ctx, w, h, text) {
    ctx.fillStyle = '#000';
    ctx.fillRect(0, 0, w, h);
    ctx.fillStyle = '#f0c';
    ctx.font = 'bold 50px Arial';
    ctx.textAlign = 'center';
    ctx.textBaseline = 'middle';
    ctx.fillText(text, w / 2, h / 2);
}

function wrapText(ctx, text, x, y, maxWidth, lineHeight) {
    const words = text.split(' ');
    let line = '';
    const lines = [];

    for (let n = 0; n < words.length; n++) {
        const testLine = line + words[n] + ' ';
        const metrics = ctx.measureText(testLine);
        const testWidth = metrics.width;
        if (testWidth > maxWidth && n > 0) {
            lines.push(line);
            line = words[n] + ' ';
        } else {
            line = testLine;
        }
    }
    lines.push(line);
    // Only verify logic, don't draw all lines if too many. draw last 4.
    for (let k = 0; k < lines.length && k < 4; k++) {
        ctx.fillText(lines[k], x, y + (k * lineHeight));
    }
}

async function loadImage(url) {
    return new Promise((resolve, reject) => {
        const img = new Image();
        img.crossOrigin = 'anonymous';
        img.onload = () => resolve(img);
        img.onerror = reject;
        img.src = url;
    });
}
