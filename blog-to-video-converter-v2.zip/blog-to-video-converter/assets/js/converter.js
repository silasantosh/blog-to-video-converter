/**
 * Blog to Video Converter v2.0
 * Structured Storyline Engine — Theme-Aware Colors & Fonts.
 * Uses actual blog content, website branding, and optional stock media.
 */

const canvas = document.getElementById('btv-canvas');
if (!canvas) throw new Error('Canvas not found');
const ctx = canvas.getContext('2d');
const W = canvas.width;   // 1280
const H = canvas.height;  // 720
const FPS = 30;

// UI
const btn = document.getElementById('btv-generate-btn');
const progressContainer = document.getElementById('btv-progress-container');
const statusEl = document.getElementById('btv-status');
const progressBar = document.getElementById('btv-progress');

// ========== THEME SYSTEM ==========
// Reads theme_style from PHP. Falls back to a premium default palette.

const ts = btvData.theme_style || {};

function cleanFont(raw) {
    // Strip CSS var() wrappers and quotes, return a usable Canvas font string
    if (!raw) return '';
    return raw.replace(/var\([^)]+\)/g, '').replace(/["']/g, '').trim();
}

const THEME = {
    primary: ts.primary || '#6c63ff',
    secondary: ts.secondary || '#ff6b6b',
    accent: ts.accent || '#ffcc00',
    background: ts.background || '#0f0c29',
    text: ts.text || '#ffffff',
    fontHeading: cleanFont(ts.fontHeading) || 'Arial, Helvetica, sans-serif',
    fontBody: cleanFont(ts.fontBody) || 'Arial, Helvetica, sans-serif',
};

// Helper to darken/lighten a hex color
function adjustColor(hex, amount) {
    hex = hex.replace('#', '');
    if (hex.length === 3) hex = hex.split('').map(c => c + c).join('');
    let r = parseInt(hex.substr(0, 2), 16);
    let g = parseInt(hex.substr(2, 2), 16);
    let b = parseInt(hex.substr(4, 2), 16);
    r = Math.min(255, Math.max(0, r + amount));
    g = Math.min(255, Math.max(0, g + amount));
    b = Math.min(255, Math.max(0, b + amount));
    return `rgb(${r},${g},${b})`;
}

function hexToRgba(hex, alpha) {
    hex = hex.replace('#', '');
    if (hex.length === 3) hex = hex.split('').map(c => c + c).join('');
    const r = parseInt(hex.substr(0, 2), 16);
    const g = parseInt(hex.substr(2, 2), 16);
    const b = parseInt(hex.substr(4, 2), 16);
    return `rgba(${r},${g},${b},${alpha})`;
}

function log(msg) {
    console.log('[BTV]', msg);
    if (statusEl) statusEl.textContent = msg;
}

// ========== STORYLINE BUILDER ==========
function buildStoryline() {
    const scenes = [];
    const site = btvData.site_name || 'Our Website';
    const siteUrl = btvData.site_url || '';
    const siteDesc = btvData.site_description || '';
    const title = btvData.post_title || 'Untitled Post';
    const excerpt = btvData.post_excerpt || '';
    const paragraphs = btvData.paragraphs || [];
    const images = [btvData.post_image, ...(btvData.content_images || [])].filter(Boolean);

    // ACT 1: Brand Intro (5s)
    scenes.push({
        type: 'brand_intro',
        duration: 5,
        siteName: site,
        siteDesc: siteDesc,
        siteUrl: siteUrl,
    });

    // ACT 2: Title Card (5s)
    scenes.push({
        type: 'title_card',
        duration: 5,
        title: title,
        image: images[0] || null,
        siteName: site,
    });

    // ACT 3-N: Content Scenes (6s each)
    if (paragraphs.length > 0) {
        paragraphs.forEach((text, i) => {
            scenes.push({
                type: 'content',
                duration: 6,
                text: text,
                sceneNumber: i + 1,
                totalScenes: paragraphs.length,
                image: images[(i + 1) % Math.max(images.length, 1)] || null,
                siteName: site,
            });
        });
    } else {
        // Short post fallback — use excerpt with longer duration
        scenes.push({
            type: 'content',
            duration: 10,
            text: excerpt,
            sceneNumber: 1,
            totalScenes: 1,
            image: images[0] || null,
            siteName: site,
        });
    }

    // ACT N+1: Key Takeaway (5s)
    scenes.push({
        type: 'takeaway',
        duration: 5,
        text: excerpt || paragraphs[0] || title,
        siteName: site,
    });

    // ACT N+2: Outro / CTA (5s)
    scenes.push({
        type: 'outro',
        duration: 5,
        siteName: site,
        siteUrl: siteUrl,
        title: title,
    });

    // Ensure minimum 30s — pad content scenes if needed
    let totalDur = scenes.reduce((sum, s) => sum + s.duration, 0);
    if (totalDur < 30) {
        const contentScenes = scenes.filter(s => s.type === 'content');
        const deficit = 30 - totalDur;
        const extraPerScene = Math.ceil(deficit / Math.max(contentScenes.length, 1));
        contentScenes.forEach(s => { s.duration += extraPerScene; });
    }

    return scenes;
}

// ========== SCENE RENDERERS (Theme-Aware) ==========

function drawBrandIntro(progress, scene) {
    // Gradient from theme background → darker
    const grad = ctx.createLinearGradient(0, 0, W, H);
    grad.addColorStop(0, THEME.background);
    grad.addColorStop(0.5, adjustColor(THEME.background, 30));
    grad.addColorStop(1, adjustColor(THEME.background, -20));
    ctx.fillStyle = grad;
    ctx.fillRect(0, 0, W, H);

    // Animated particles (using primary color)
    for (let i = 0; i < 40; i++) {
        const x = (Math.sin(progress * 3 + i * 1.1) * 0.5 + 0.5) * W;
        const y = (Math.cos(progress * 2 + i * 0.7) * 0.5 + 0.5) * H;
        ctx.beginPath();
        ctx.arc(x, y, 2 + Math.sin(i) * 1.5, 0, Math.PI * 2);
        ctx.fillStyle = hexToRgba(THEME.primary, 0.1 + Math.sin(progress * 5 + i) * 0.1);
        ctx.fill();
    }

    // Site name — fade in
    const alpha = Math.min(1, progress * 3);
    ctx.globalAlpha = alpha;
    ctx.fillStyle = THEME.text;
    ctx.font = `bold 72px ${THEME.fontHeading}`;
    ctx.textAlign = 'center';
    ctx.textBaseline = 'middle';
    ctx.shadowColor = hexToRgba(THEME.primary, 0.5);
    ctx.shadowBlur = 25;
    ctx.fillText(scene.siteName, W / 2, H / 2 - 30);

    // Tagline
    ctx.font = `28px ${THEME.fontBody}`;
    ctx.fillStyle = hexToRgba(THEME.primary, 0.7);
    ctx.shadowBlur = 0;
    ctx.fillText(scene.siteDesc, W / 2, H / 2 + 40);

    // URL
    ctx.font = `20px ${THEME.fontBody}`;
    ctx.fillStyle = hexToRgba(THEME.text, 0.5);
    ctx.fillText(scene.siteUrl, W / 2, H / 2 + 80);

    // Decorative line using primary
    const lineW = 200 * alpha;
    ctx.fillStyle = THEME.primary;
    ctx.fillRect(W / 2 - lineW / 2, H / 2 + 55, lineW, 3);

    ctx.globalAlpha = 1;
    ctx.shadowBlur = 0;
}

function drawTitleCard(progress, scene, img) {
    if (img) {
        ctx.filter = 'blur(15px) brightness(0.4)';
        ctx.drawImage(img, -20, -20, W + 40, H + 40);
        ctx.filter = 'none';
    } else {
        const grad = ctx.createLinearGradient(0, 0, W, H);
        grad.addColorStop(0, THEME.background);
        grad.addColorStop(1, adjustColor(THEME.background, 20));
        ctx.fillStyle = grad;
        ctx.fillRect(0, 0, W, H);
    }

    // Overlay
    ctx.fillStyle = 'rgba(0, 0, 0, 0.5)';
    ctx.fillRect(0, 0, W, H);

    // Title — slide up
    const offsetY = Math.max(0, (1 - progress * 2) * 50);
    const alpha = Math.min(1, progress * 2.5);
    ctx.globalAlpha = alpha;

    ctx.fillStyle = THEME.text;
    ctx.font = `bold 64px ${THEME.fontHeading}`;
    ctx.textAlign = 'center';
    ctx.textBaseline = 'middle';
    ctx.shadowColor = 'rgba(0,0,0,0.8)';
    ctx.shadowBlur = 15;
    wrapText(ctx, scene.title, W / 2, H / 2 - 20 + offsetY, W - 200, 75);

    // Decorative accent bar under title
    ctx.fillStyle = THEME.primary;
    ctx.shadowBlur = 0;
    const barW = 120 * alpha;
    ctx.fillRect(W / 2 - barW / 2, H / 2 + 60 + offsetY, barW, 4);

    // Site watermark top-left
    ctx.font = `22px ${THEME.fontBody}`;
    ctx.fillStyle = hexToRgba(THEME.text, 0.6);
    ctx.textAlign = 'left';
    ctx.fillText(scene.siteName, 40, 40);

    ctx.globalAlpha = 1;
    ctx.shadowBlur = 0;
}

function drawContent(progress, scene, img) {
    if (img) {
        // Ken Burns
        const scale = 1.0 + progress * 0.15;
        const dw = W * scale;
        const dh = (W / img.width * img.height) * scale;
        const dx = -(dw - W) / 2 + Math.sin(progress * 2) * 20;
        const dy = -(dh - H) / 2;
        ctx.drawImage(img, dx, dy, dw, dh);
        ctx.fillStyle = 'rgba(0, 0, 0, 0.55)';
        ctx.fillRect(0, 0, W, H);
    } else {
        // Use theme-aware gradient
        const grad = ctx.createLinearGradient(0, 0, W, H);
        grad.addColorStop(0, adjustColor(THEME.background, 10 + scene.sceneNumber * 8));
        grad.addColorStop(1, adjustColor(THEME.background, -10 + scene.sceneNumber * 5));
        ctx.fillStyle = grad;
        ctx.fillRect(0, 0, W, H);
    }

    // Scene number badge (theme primary)
    ctx.fillStyle = hexToRgba(THEME.primary, 0.85);
    roundRect(ctx, 40, 30, 120, 45, 22);
    ctx.fill();
    ctx.fillStyle = THEME.text;
    ctx.font = `bold 18px ${THEME.fontBody}`;
    ctx.textAlign = 'center';
    ctx.fillText(`${scene.sceneNumber} / ${scene.totalScenes}`, 100, 58);

    // Site watermark top-right
    ctx.font = `18px ${THEME.fontBody}`;
    ctx.fillStyle = hexToRgba(THEME.text, 0.5);
    ctx.textAlign = 'right';
    ctx.fillText(scene.siteName, W - 40, 55);

    // Text area at bottom
    const boxH = 220;
    const boxY = H - boxH - 30;
    ctx.fillStyle = 'rgba(0, 0, 0, 0.7)';
    roundRect(ctx, 40, boxY, W - 80, boxH, 16);
    ctx.fill();

    // Border accent (theme primary)
    ctx.strokeStyle = hexToRgba(THEME.primary, 0.5);
    ctx.lineWidth = 2;
    roundRect(ctx, 40, boxY, W - 80, boxH, 16);
    ctx.stroke();

    // Text — typewriter effect
    const fullText = scene.text;
    const charsToShow = Math.floor(progress * fullText.length * 1.5);
    const visibleText = fullText.substring(0, Math.min(charsToShow, fullText.length));

    ctx.fillStyle = THEME.text;
    ctx.font = `28px ${THEME.fontBody}`;
    ctx.textAlign = 'left';
    ctx.textBaseline = 'top';
    wrapTextLeft(ctx, visibleText, 70, boxY + 25, W - 160, 38);
}

function drawTakeaway(progress, scene) {
    // Use secondary/accent gradient
    const grad = ctx.createLinearGradient(0, 0, W, H);
    grad.addColorStop(0, THEME.secondary);
    grad.addColorStop(1, adjustColor(THEME.secondary, -40));
    ctx.fillStyle = grad;
    ctx.fillRect(0, 0, W, H);

    // Big quote icon
    ctx.fillStyle = hexToRgba(THEME.text, 0.12);
    ctx.font = `bold 300px Georgia, serif`;
    ctx.textAlign = 'center';
    ctx.fillText('"', W / 2, H / 2 - 80);

    // Text
    const alpha = Math.min(1, progress * 3);
    ctx.globalAlpha = alpha;
    ctx.fillStyle = THEME.text;
    ctx.font = `bold 36px ${THEME.fontHeading}`;
    ctx.textAlign = 'center';
    ctx.shadowColor = 'rgba(0,0,0,0.4)';
    ctx.shadowBlur = 10;
    wrapText(ctx, scene.text, W / 2, H / 2, W - 200, 48);

    // Label
    ctx.font = `20px ${THEME.fontBody}`;
    ctx.fillStyle = hexToRgba(THEME.text, 0.7);
    ctx.shadowBlur = 0;
    ctx.fillText('\u2014 Key Takeaway \u2014', W / 2, H - 80);

    // Site
    ctx.fillText(scene.siteName, W / 2, H - 50);

    ctx.globalAlpha = 1;
    ctx.shadowBlur = 0;
}

function drawOutro(progress, scene) {
    const grad = ctx.createLinearGradient(0, 0, W, H);
    grad.addColorStop(0, THEME.background);
    grad.addColorStop(0.5, adjustColor(THEME.background, 30));
    grad.addColorStop(1, THEME.background);
    ctx.fillStyle = grad;
    ctx.fillRect(0, 0, W, H);

    const alpha = Math.min(1, progress * 2);
    ctx.globalAlpha = alpha;

    // "Thanks for watching"
    ctx.fillStyle = THEME.text;
    ctx.font = `bold 52px ${THEME.fontHeading}`;
    ctx.textAlign = 'center';
    ctx.textBaseline = 'middle';
    ctx.fillText('Thanks for Watching!', W / 2, H / 2 - 80);

    // Decorative line (primary)
    ctx.fillStyle = THEME.primary;
    ctx.fillRect(W / 2 - 100, H / 2 - 30, 200, 3);

    // Blog title
    ctx.font = `30px ${THEME.fontBody}`;
    ctx.fillStyle = hexToRgba(THEME.primary, 0.8);
    wrapText(ctx, '\u201C' + scene.title + '\u201D', W / 2, H / 2 + 20, W - 200, 40);

    // CTA (accent color)
    ctx.font = `bold 28px ${THEME.fontBody}`;
    ctx.fillStyle = THEME.accent;
    ctx.fillText('Read the full article at', W / 2, H / 2 + 90);

    // URL
    ctx.font = `bold 32px ${THEME.fontHeading}`;
    ctx.fillStyle = THEME.text;
    ctx.fillText(scene.siteUrl, W / 2, H / 2 + 130);

    // Copyright
    ctx.font = `20px ${THEME.fontBody}`;
    ctx.fillStyle = hexToRgba(THEME.text, 0.4);
    ctx.fillText('\u00A9 ' + scene.siteName, W / 2, H - 40);

    ctx.globalAlpha = 1;
}

// ========== HELPERS ==========

function wrapText(ctx, text, x, y, maxWidth, lineHeight) {
    const words = text.split(' ');
    let line = '';
    const lines = [];
    for (const word of words) {
        const test = line + word + ' ';
        if (ctx.measureText(test).width > maxWidth && line.length > 0) {
            lines.push(line.trim());
            line = word + ' ';
        } else {
            line = test;
        }
    }
    lines.push(line.trim());

    const startY = y - ((lines.length - 1) * lineHeight) / 2;
    for (let i = 0; i < lines.length; i++) {
        ctx.fillText(lines[i], x, startY + i * lineHeight);
    }
}

function wrapTextLeft(ctx, text, x, y, maxWidth, lineHeight) {
    const words = text.split(' ');
    let line = '';
    let lineY = y;
    for (const word of words) {
        const test = line + word + ' ';
        if (ctx.measureText(test).width > maxWidth && line.length > 0) {
            ctx.fillText(line.trim(), x, lineY);
            line = word + ' ';
            lineY += lineHeight;
        } else {
            line = test;
        }
    }
    ctx.fillText(line.trim(), x, lineY);
}

function roundRect(ctx, x, y, w, h, r) {
    ctx.beginPath();
    ctx.moveTo(x + r, y);
    ctx.lineTo(x + w - r, y);
    ctx.quadraticCurveTo(x + w, y, x + w, y + r);
    ctx.lineTo(x + w, y + h - r);
    ctx.quadraticCurveTo(x + w, y + h, x + w - r, y + h);
    ctx.lineTo(x + r, y + h);
    ctx.quadraticCurveTo(x, y + h, x, y + h - r);
    ctx.lineTo(x, y + r);
    ctx.quadraticCurveTo(x, y, x + r, y);
    ctx.closePath();
}

function loadImage(url) {
    return new Promise((resolve) => {
        const img = new Image();
        img.crossOrigin = 'anonymous';
        img.onload = () => resolve(img);
        img.onerror = () => resolve(null);
        img.src = url;
    });
}

// ========== MAIN RENDER LOOP ==========

async function generate() {
    log('Building storyline...');
    const scenes = buildStoryline();

    // Pre-load all images
    log('Loading images...');
    const imageMap = new Map();
    const allUrls = new Set();
    for (const s of scenes) {
        if (s.image) allUrls.add(s.image);
    }
    for (const url of allUrls) {
        const img = await loadImage(url);
        if (img) imageMap.set(url, img);
    }

    // Try Pollinations for content scenes without images
    for (const scene of scenes) {
        if (scene.type === 'content' && !scene.image) {
            const keyword = scene.text.split(' ').filter(w => w.length > 4).slice(0, 4).join(' ');
            const polUrl = `https://image.pollinations.ai/prompt/${encodeURIComponent(keyword + ' professional photo')}?width=1280&height=720&nologo=true`;
            log(`Generating AI image for scene ${scene.sceneNumber}...`);
            const img = await loadImage(polUrl);
            if (img) {
                scene.image = polUrl;
                imageMap.set(polUrl, img);
            }
        }
    }

    // Calculate total frames
    let totalDuration = 0;
    for (const s of scenes) totalDuration += s.duration;
    const totalFrames = totalDuration * FPS;

    log('Recording video...');
    const stream = canvas.captureStream(FPS);
    const recorder = new MediaRecorder(stream, {
        mimeType: 'video/webm; codecs=vp8',
        videoBitsPerSecond: 4000000
    });
    const chunks = [];
    recorder.ondataavailable = e => { if (e.data.size > 0) chunks.push(e.data); };
    recorder.start(100);

    let frameIndex = 0;
    for (const scene of scenes) {
        const sceneFrames = scene.duration * FPS;
        const img = scene.image ? imageMap.get(scene.image) : null;

        for (let f = 0; f < sceneFrames; f++) {
            const progress = f / sceneFrames;

            ctx.clearRect(0, 0, W, H);
            ctx.globalAlpha = 1;
            ctx.shadowBlur = 0;
            ctx.textAlign = 'center';
            ctx.textBaseline = 'middle';

            switch (scene.type) {
                case 'brand_intro': drawBrandIntro(progress, scene); break;
                case 'title_card': drawTitleCard(progress, scene, img); break;
                case 'content': drawContent(progress, scene, img); break;
                case 'takeaway': drawTakeaway(progress, scene); break;
                case 'outro': drawOutro(progress, scene); break;
            }

            frameIndex++;
            if (frameIndex % FPS === 0) {
                const pct = Math.round((frameIndex / totalFrames) * 100);
                progressBar.value = pct;
                log(`Rendering: ${pct}% (${scene.type})`);
                await new Promise(r => setTimeout(r, 0));
            }
            await new Promise(r => requestAnimationFrame(r));
        }
    }

    await new Promise(r => setTimeout(r, 500));
    recorder.stop();
    log('Finalizing...');
    await new Promise(r => (recorder.onstop = r));

    const blob = new Blob(chunks, { type: 'video/webm' });
    log(`Video size: ${(blob.size / 1024 / 1024).toFixed(1)} MB. Uploading...`);

    const formData = new FormData();
    formData.append('action', 'btv_upload_video');
    formData.append('nonce', btvData.nonce);
    formData.append('post_id', btvData.post_id);
    formData.append('video', blob, 'blog-video-' + btvData.post_id + '.webm');

    const res = await fetch(btvData.ajaxurl, { method: 'POST', body: formData });
    const json = await res.json();

    if (json.success) {
        log('✅ Done! Reloading...');
        setTimeout(() => location.reload(), 1500);
    } else {
        throw new Error(json.data || 'Upload failed');
    }
}

// ========== EVENT LISTENER ==========

if (btn) {
    btn.addEventListener('click', async () => {
        const info = `This will generate a video from your blog post.\n\nStoryline:\n• Website branding intro\n• Post title card\n• Content scenes from your post\n• Key takeaway\n• Outro with your website URL\n\nProceed?`;
        if (!confirm(info)) return;

        btn.disabled = true;
        progressContainer.style.display = 'block';
        log('Starting...');

        try {
            await generate();
        } catch (e) {
            console.error(e);
            log('❌ Error: ' + e.message);
            btn.disabled = false;
        }
    });
}
