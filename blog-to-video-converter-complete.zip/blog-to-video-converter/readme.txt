=== Blog to Video Converter ===
Contributors: antigravity
Tags: video, ai, content-to-video, text-to-speech, ffmpeg
Requires at least: 6.0
Tested up to: 6.7
Stable tag: 1.1.0
License: GPLv2 or later
License URI: https://www.gnu.org/licenses/gpl-2.0.html

Automatically converts blog posts into video content using AI (Summarization & TTS) and client-side rendering.

== Description ==

Turn your blog posts into engaging videos directly from your browser! This plugin uses advanced AI (Transformers.js) and WebAssembly (FFmpeg.wasm) to:

1.  **Summarize** your post content into a video script.
2.  **Generate Voiceover** using AI Text-to-Speech.
3.  **Render Visuals** using your post title and featured image.
4.  **Export as MP4** so you can share it anywhere.

**Privacy Focused**: All processing happens **locally** in your browser. No API keys are required, and no data is sent to external servers for processing (except for downloading the initial open-source AI models from Hugging Face).

== Installation ==

1.  Upload the plugin files to the `/wp-content/plugins/blog-to-video-converter` directory, or install the plugin through the WordPress plugins screen.
2.  Activate the plugin through the 'Plugins' screen in WordPress.
3.  **Important**: Your server must support `Cross-Origin-Opener-Policy` and `Cross-Origin-Embedder-Policy` headers for the high-performance mode. The plugin attempts to set these automatically.

== How to Use ==

1.  Go to **Posts** and edit any blog post.
2.  Ensure the post has a **Featured Image** (this will be the main visual).
3.  Look for the **Blog to Video** box (usually in the sidebar or at the bottom).
4.  Click **Generate Video**.
5.  **Wait**: The first time you run it, it will download ~200MB of AI models. Do not close the tab.
6.  Once finished, the page will reload, and the video will be attached to the top of your post.

== Frequently Asked Questions ==

= Why is it stuck on "Loading AI Models"? =
This depends on your internet speed. It needs to download the models once. Open your browser console (F12) to see progress.

= Why do I get a "SharedArrayBuffer" error? =
This means your site isn't serving the required security headers. The plugin tries to add them, but some hosting providers block this. If this happens, the plugin will try to fall back to a "Basic Mode" (WebM video, no AI voice).

== Changelog ==

= 1.1.0 =
*   Added AI Summarization and TTS.
*   Added MP4 export via FFmpeg.wasm.
*   Fixed Linux installation issues.

= 1.0.0 =
*   Initial release.
