<?php
/**
 * BTV Global Schema Intelligence
 * Supports 23+ Schema.org types for ultimate SEO.
 */

if (!defined('ABSPATH'))
    exit;

class BTV_SEO
{
    private $types = array(
        'article' => 'Article',
        'book' => 'Book',
        'breadcrumb' => 'Breadcrumb',
        'course' => 'Course',
        'dataset' => 'Dataset',
        'event' => 'Event',
        'faq' => 'FAQ',
        'howto' => 'How To',
        'jobposting' => 'Job Posting',
        'localbusiness' => 'Local Business',
        'organization' => 'Organization',
        'person' => 'Person',
        'product' => 'Product',
        'productreview' => 'Product Review',
        'merchantcenter' => 'Merchant Center',
        'factcheck' => 'Fact Check',
        'car' => 'Car',
        'music' => 'Music',
        'recipe' => 'Recipe',
        'service' => 'Service',
        'software' => 'Software',
        'video' => 'Video',
        'webpage' => 'Web Page'
    );

    public function __construct()
    {
        add_action('wp_head', array($this, 'inject_all_schemas'));
    }

    /**
     * Entry point for SEO injection.
     */
    public function inject_all_schemas()
    {
        if (!is_singular())
            return;

        $schemas = array();

        // 1. Core Schemas (Always useful for blogs)
        if ($this->is_enabled('article'))
            $schemas[] = $this->gen_article();
        if ($this->is_enabled('webpage'))
            $schemas[] = $this->gen_webpage();
        if ($this->is_enabled('breadcrumb'))
            $schemas[] = $this->gen_breadcrumb();
        if ($this->is_enabled('organization'))
            $schemas[] = $this->gen_organization();
        if ($this->is_enabled('person'))
            $schemas[] = $this->gen_person();

        // 2. Video Schema (Integrated with BTV)
        if ($this->is_enabled('video'))
            $schemas[] = $this->gen_video();

        // 3. Dynamic Schemas (Auto-detected from content)
        if ($this->is_enabled('faq'))
            $schemas[] = $this->gen_faq();
        if ($this->is_enabled('howto'))
            $schemas[] = $this->gen_howto();

        // 4. E-commerce & Service Lite
        if ($this->is_enabled('product'))
            $schemas[] = $this->gen_product();

        // Filter out empties
        $schemas = array_filter($schemas);

        if (empty($schemas))
            return;

        echo "\n<!-- Blog to Video Global Schema v2.0.0 -->\n";
        foreach ($schemas as $s) {
            echo '<script type="application/ld+json">' . json_encode($s, JSON_UNESCAPED_SLASHES | JSON_PRETTY_PRINT) . '</script>' . "\n";
        }
        echo "<!-- / Blog to Video Global Schema -->\n";
    }

    private function is_enabled($type)
    {
        $options = get_option('btv_enabled_schemas', array('article', 'webpage', 'video', 'breadcrumb', 'organization', 'person'));
        return in_array($type, $options);
    }

    private function gen_article()
    {
        global $post;
        return array(
            "@context" => "https://schema.org",
            "@type" => "Article",
            "headline" => get_the_title(),
            "image" => get_the_post_thumbnail_url(),
            "author" => array("@type" => "Person", "name" => get_the_author()),
            "publisher" => array(
                "@type" => "Organization",
                "name" => get_bloginfo('name'),
                "logo" => array("@type" => "ImageObject", "url" => get_site_icon_url())
            ),
            "datePublished" => get_the_date('c'),
            "dateModified" => get_the_modified_date('c')
        );
    }

    private function gen_webpage()
    {
        return array(
            "@context" => "https://schema.org",
            "@type" => "WebPage",
            "name" => get_the_title(),
            "url" => get_permalink(),
            "description" => get_the_excerpt()
        );
    }

    private function gen_video()
    {
        $post_id = get_the_ID();
        $video_url = get_post_meta($post_id, '_btv_video_url', true);
        if (empty($video_url))
            return null;

        return array(
            "@context" => "https://schema.org",
            "@type" => "VideoObject",
            "name" => get_the_title(),
            "description" => get_the_excerpt() ?: wp_trim_words(get_post_field('post_content', $post_id), 30),
            "thumbnailUrl" => array(get_the_post_thumbnail_url() ?: 'https://via.placeholder.com/1280x720'),
            "uploadDate" => get_the_modified_date('c'),
            "contentUrl" => $video_url
        );
    }

    private function gen_faq()
    {
        $content = get_post_field('post_content', get_the_ID());
        preg_match_all('/<(h[2-4])>(.*?)<\/h\1>.*?<p>(.*?)<\/p>/is', $content, $matches);

        if (empty($matches[0]))
            return null;

        $questions = array();
        for ($i = 0; $i < min(5, count($matches[2])); $i++) {
            $questions[] = array(
                "@type" => "Question",
                "name" => wp_strip_all_tags($matches[2][$i]),
                "acceptedAnswer" => array(
                    "@type" => "Answer",
                    "text" => wp_strip_all_tags($matches[3][$i])
                )
            );
        }

        return !empty($questions) ? array(
            "@context" => "https://schema.org",
            "@type" => "FAQPage",
            "mainEntity" => $questions
        ) : null;
    }

    private function gen_howto()
    {
        // Simple detection of ordered lists as steps
        $content = get_post_field('post_content', get_the_ID());
        if (strpos($content, '<ol>') === false)
            return null;

        preg_match('/<ol>(.*?)<\/ol>/is', $content, $match);
        if (empty($match[1]))
            return null;

        preg_match_all('/<li>(.*?)<\/li>/is', $match[1], $items);
        if (empty($items[1]))
            return null;

        $steps = array();
        foreach ($items[1] as $i => $step_text) {
            $steps[] = array(
                "@type" => "HowToStep",
                "name" => "Step " . ($i + 1),
                "text" => wp_strip_all_tags($step_text),
                "url" => get_permalink() . "#step" . ($i + 1)
            );
        }

        return array(
            "@context" => "https://schema.org",
            "@type" => "HowTo",
            "name" => get_the_title(),
            "step" => $steps
        );
    }

    private function gen_organization()
    {
        return array(
            "@context" => "https://schema.org",
            "@type" => "Organization",
            "name" => get_bloginfo('name'),
            "url" => home_url(),
            "logo" => get_site_icon_url()
        );
    }

    private function gen_person()
    {
        return array(
            "@context" => "https://schema.org",
            "@type" => "Person",
            "name" => get_the_author(),
            "url" => get_author_posts_url(get_the_author_meta('ID'))
        );
    }

    private function gen_breadcrumb()
    {
        return array(
            "@context" => "https://schema.org",
            "@type" => "BreadcrumbList",
            "itemListElement" => array(
                    array("@type" => "ListItem", "position" => 1, "name" => "Home", "item" => home_url()),
                    array("@type" => "ListItem", "position" => 2, "name" => get_the_title(), "item" => get_permalink())
            )
        );
    }

    private function gen_product()
    {
        // Very basic placeholder for product blocks
        return null;
    }

    public function get_supported_types()
    {
        return $this->types;
    }
}
