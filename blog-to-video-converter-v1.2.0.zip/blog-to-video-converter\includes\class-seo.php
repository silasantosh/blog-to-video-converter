<?php
/**
 * BTV SEO Component
 * Handles Schema.org VideoObject JSON-LD generation.
 */

if (!defined('ABSPATH'))
    exit;

class BTV_SEO
{
    public function __construct()
    {
        add_action('wp_head', array($this, 'inject_video_schema'));
    }

    /**
     * Injects VideoObject schema into the head of singular posts.
     */
    public function inject_video_schema()
    {
        if (!is_singular())
            return;

        $post_id = get_the_ID();
        $video_url = get_post_meta($post_id, '_btv_video_url', true);

        if (empty($video_url))
            return;

        $title = get_the_title($post_id);
        $excerpt = get_the_excerpt($post_id);
        if (empty($excerpt)) {
            $excerpt = wp_trim_words(get_post_field('post_content', $post_id), 30);
        }

        $thumbnail = get_the_post_thumbnail_url($post_id, 'large');
        if (!$thumbnail) {
            // Fallback to placeholder or first image in content if needed
            $thumbnail = 'https://via.placeholder.com/1280x720?text=' . urlencode($title);
        }

        $upload_date = get_the_modified_date('c', $post_id);

        $schema = array(
            "@context" => "https://schema.org",
            "@type" => "VideoObject",
            "name" => $title,
            "description" => $excerpt,
            "thumbnailUrl" => array(
                $thumbnail
            ),
            "uploadDate" => $upload_date,
            "contentUrl" => $video_url,
            "embedUrl" => add_query_arg('btv_embed', 1, get_permalink($post_id)), // Future-proofing
            "potentialAction" => array(
                "@type" => "SeekAction",
                "target" => get_permalink($post_id) . "?t={seek_to_second_number}",
                "startOffset-input" => "name=seek_to_second_number"
            )
        );

        echo "\n<!-- Blog to Video SEO -->\n";
        echo '<script type="application/ld+json">' . json_encode($schema, JSON_UNESCAPED_SLASHES | JSON_PRETTY_PRINT) . '</script>';
        echo "\n<!-- / Blog to Video SEO -->\n";
    }
}
